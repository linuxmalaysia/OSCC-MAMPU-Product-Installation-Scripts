#!/bin/bash

##load database

if [ $1 -eq 1 ]; then

  echo "Configuration Start. Please answer all the questions"

  service mysqld status | grep 'is running'>/dev/null 2>&1 || service mysqld start
   
  mysql < /etc/mailwatch/create.sql

  echo "GRANT ALL ON mailscanner.* TO mailwatch@localhost IDENTIFIED BY 'mailwatch123';">/tmp/mailwatch-install-$$.tmp

  mysql mailscanner < /tmp/mailwatch-install-$$.tmp

  #mysql mailscanner -u mailwatch -p mailwatch123

  echo "INSERT INTO users VALUES ('admin',md5('admin'),'admin','A','0','0','0','0','0');">/tmp/mailwatch-install2-$$.tmp

  mysql mailscanner < /tmp/mailwatch-install2-$$.tmp

  #mysql > INSERT INTO users VALUES ('admin',md5('admin'),'admin','A','0','0','0','0','0');

fi

#change permission of /var/www/html/mailscanner

chown apache:apache /var/www/html/mailscanner/images
chmod ug+rwx /var/www/html/mailscanner/images
chown apache:apache /var/www/html/mailscanner/cache
chmod ug+rwx /var/www/html/mailscanner/cache
chown apache /var/www/html/mailscanner/temp
chmod g+w /var/www/html/mailscanner/temp

#copy conf.php.example and rename it as conf.php
#cp %{buildroot}/var/www/html/mailscanner/conf.php.example %{buildroot}/var/www/html/mailscanner/conf.php

# Send the information
#wget http://www.oscc.org.my/myspamguard.html
