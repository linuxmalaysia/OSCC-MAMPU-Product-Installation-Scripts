<?
/*
 MailWatch for MailScanner
 Copyright (C) 2004  Steve Freegard (smf@f2s.com)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

require("./functions.php");
authenticate('A');
html_start("GeoIP Database Update");

if(!isset($_POST['run'])) {
?>
<FORM METHOD="POST" ACTION=<?=$_SERVER['PHP_SELF']?>>
<INPUT TYPE="HIDDEN" NAME="run" VALUE="true">
<TABLE CLASS="BOXTABLE" WIDTH="100%">
 <TR>
  <TD>
   This utility is used to update the SQL database with up-to-date GeoIP data from <a href="http://www.maxmind.com/app/geoip_country">MaxMind</a> which is used to work out the country of origin for any given IP address and is displayed on the Message Detail page.<BR>
   <BR>
  </TD>
 </TR>
 <TR>
  <TD ALIGN="CENTER"><BR><INPUT TYPE="SUBMIT" VALUE="Run Now"><BR><BR></TD>
 </TR>
<TABLE>
<?
html_end();
} else {
 echo "Downloading file, please wait....<BR>\n";
 $file = 'temp/GeoIPCountryCSV.zip';
 $file2 = 'temp/GeoIPCountryWhois.csv';
 $base = dirname(__FILE__);
 // Clean-up from last run
 if(file_exists($file)) { unlink($file); }
 if(file_exists($file2)) { unlink($file2); }
 // Download GeoIP CSV file
 if($ufh = fopen("http://www.maxmind.com/download/geoip/database/GeoIPCountryCSV.zip","r")) {
  // Open local file for writing
  if($lfh = fopen($file,"w+")) {
   do {
    $data = fread($ufh,8192);
    if(strlen($data)==0) {
     break;
    }
    fwrite($lfh,$data);
   } while(true);
   fclose($ufh);
   fclose($lfh);
  } else {
   die("Unable to open $file for writing.\n");
  }
 } else {
  die("Unable to download GeoIP data file.\n");
 }
 // Unzip the file (unzip required)
 $exec = exec('unzip -d temp/ '.$file, $output, $retval);
 if($retval==0) {
  // Drop the data from the table
  dbquery("DELETE FROM geoip_country");
  // Load the data
  dbquery("LOAD DATA INFILE '".$base.'/'.$file2."' INTO TABLE geoip_country FIELDS TERMINATED BY ',' ENCLOSED BY '\"'");
  // Done return the number of rows
  echo "Download complete ... ".mysql_result(dbquery("SELECT COUNT(*) FROM geoip_country"),0)." rows imported.<BR>\n";
  audit_log('Ran GeoIP update');
 } else {
  die("Unzip failed:<BR>Error: ".join("<BR>",$output)."<BR>\n");
 }
 html_end();
}
?>
