<?
require('functions.php');
html_start("MySQL Status");
audit_log('Viewed MySQL Status');
dbtable("SHOW TABLE STATUS");
echo "<BR/>\n";
dbtable("SHOW FULL PROCESSLIST");
echo "<BR/>\n";
dbtable("SHOW VARIABLES");
html_end();
?>
