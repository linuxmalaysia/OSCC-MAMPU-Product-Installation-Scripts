<?php
/*
 MailWatch for MailScanner
 Copyright (C) 2003  Steve Freegard (smf@f2s.com)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

require_once('functions.php');
authenticate();

function simple_html_start() {
?>
<html>
<head>
<title>MailWatch for MaiLScanner</title>
<style type="text/css">
<!--
BODY {
 margin: 0 0
 font-family: sans-serif;
 font-size: 8pt;
}

TH {
 background-color: #F7CE4A;
}
-->
</style>
<body>
<?php
}

function simple_html_end() {
?>
</body>
</html>
<?php
}

function simple_html_result($status) {
?>
<table class="box" width="100%" height="100%">
 <tr>
  <td valign="middle" align="center">
   <table border=0>
    <tr><th>Result</th></tr>
    <tr><td><?=$status?></td></tr>
    <tr><td align="center"><b><a href="javascript:window.close()">Close Window</a></td></tr>
  </td>
 </tr>
</table>
<?php
}

switch(false) {
 case (isset($_GET['id'])):
  die("Error: No Message ID");
  break;
 case (isset($_GET['action'])):
  die("Error: No action");
  break;
}


$list = quarantine_list_items($_GET['id']);
if(count($list) == 0) {
 die("Error: Message not found in quarantine");
}


switch($_GET['action']) {

 case 'release':
  if(count($list) == 1) {
   $to = $list[0]['to'];
   $result = quarantine_release($list,array(0),$to);
  } else {
   for($i=0;$i<count($list);$i++) {
    if(preg_match('/message\/rfc822/',$list[$i]['type'])) {
     $result = quarantine_release($list,array($i),$list[$i]['to']);
    }
   }
  }
  
  if(isset($_GET['html'])) { 
   // Display success
   simple_html_start();
   simple_html_result($result);
   simple_html_end();
  }
  break;

 case 'delete':
  if(isset($_GET['html'])) {
   if(!isset($_GET['confirm'])) {
    // Dislay an 'Are you sure' dialog
    simple_html_start();
?>
<table width="100%" height="100%">
 <tr>
  <td align="center" valign="middle">
   <table>
    <tr><th>Delete: Are you sure?</th></tr>
    <tr><td align="center"><a href="<?=$_SERVER['PHP_SELF']?>?id=<?=$_GET['id']?>&action=delete&html=true&confirm=true">Yes</a>&nbsp;&nbsp</a><a href="javascript:void(0)" onClick="javascript:window.close()">No</a></td></tr>
   </table>
  </td>
 </tr>
</table>
<?php
    simple_html_end();
   } else {
    simple_html_start();
    for($i=0;$i<count($list);$i++) {
     $status[] = quarantine_delete($list,array($i));
    }
    $status = join('<br/>',$status);
    simple_html_result($status);
    simple_html_end();
   }
  } else {
   // Delete
   for($i=0;$i<count($list);$i++) {
    $status[] = quarantine_delete($list,array($i));
   }
  }
  break;
 
 case 'learn':
  break;

 default:
  die("Unknown action: ".$_GET['action']);
  break;
}


?>
</body>
</html>
