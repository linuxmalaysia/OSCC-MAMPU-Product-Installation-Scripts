<?php
/*
 MailWatch for MailScanner
 Copyright (C) 2003  Steve Freegard (smf@f2s.com)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

require('functions.php');
authenticate();
html_start('Tools');

?>
<TABLE WIDTH=100% CLASS="BOXTABLE">
 <TR>
  <TD>
   <UL>
    <? if(!MSEE): ?>
     <LI><A HREF="user_manager.php">User Management</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && preg_match('/sophos/i',get_conf_var('VirusScanners')) && $GLOBALS['user_type'] == 'A'): ?> 
     <LI><A HREF="sophos_status.php">Sophos Status</A> 
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && preg_match('/f-secure/i',get_conf_var('VirusScanners'))): ?>
     <LI><A HREF="f-secure_status.php">F-Secure Status</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && preg_match('/clamav/i',get_conf_var('VirusScanners'))): ?>
     <LI><A HREF="clamav_status.php">ClamAV Status</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && preg_match('/mcafee/i',get_conf_var('VirusScanners'))): ?>
     <LI><A HREF="mcafee_status.php">McAfee Status</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && preg_match('/f-prot/i',get_conf_var('VirusScanners'))): ?>
     <LI><A HREF="f-prot_status.php">F-Prot Status</A>
    <? endif; ?>
    <? if($GLOBALS['user_type'] == 'A'): ?>
    <LI><A HREF="mysql_status.php">MySQL Database Status</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && $GLOBALS['user_type'] == 'A'): ?>    
     <LI><A HREF="msconfig.php">View MailScanner Configuration</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && get_conf_truefalse('UseSpamAssassin') && $GLOBALS['user_type'] == 'A'): ?>
     <LI><A HREF="bayes_info.php">SpamAssassin Bayes Database Info</A>
     <LI><A HREF="sa_lint.php">SpamAssassin Lint (Test)</A>
     <LI><A HREF="sa_rules_update.php">Update SpamAssasin Rule Descriptions</A>
    <? endif; ?>
    <? if(!DISTRIBUTED_SETUP && get_conf_truefalse('MCPChecks') && $GLOBALS['user_type'] == 'A'): ?>
     <LI><A HREF="mcp_rules_update.php">Update MCP Rule Descriptions</A>
    <? endif; ?>
    <? if($GLOBALS['user_type'] == 'A'): ?>
     <LI><A HREF="geoip_update.php">Update GeoIP Database</A>
    <? endif; ?>
   </UL>
   <P>Links</P>
   <UL>
    <LI><A HREF="http://mailwatch.sourceforge.net">MailWatch for MailScanner</A>

    <LI><A HREF="http://www.mailscanner.info">MailScanner</A> 
    <? if(get_conf_truefalse('UseSpamAssassin')): ?>
     <LI><A HREF="http://www.spamassassin.org">SpamAssassin</A>
    <? endif; ?>
    <? if(preg_match('/sophos/i',get_conf_var('VirusScanners'))): ?>
     <LI><A HREF="http://www.sophos.com">Sophos</A>
    <? endif; ?>
    <? if(preg_match('/clamav/i',get_conf_var('VirusScanners'))): ?>
     <LI><A HREF="http://clamav.sourceforge.net">ClamAV</A>
    <? endif; ?>
    <LI><A HREF="http://www.dnsstuff.com">DNSstuff</A>
    <LI><A HREF="http://www.samspade.org">Sam Spade</A>
    <LI><A HREF="http://spam.abuse.net">spam.abuse.net</A>
    <LI><A HREF="http://www.dnsreport.com">DNS Report</A>
   </UL>
  </TD>
 </TR>
</TABLE>
<?
html_end();
?>
