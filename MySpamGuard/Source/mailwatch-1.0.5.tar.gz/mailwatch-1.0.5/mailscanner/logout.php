<?
require './functions.php';
logout();
header("Location: index.php");
?>
