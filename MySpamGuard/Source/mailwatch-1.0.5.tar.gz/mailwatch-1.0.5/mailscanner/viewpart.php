<?
require 'functions.php';
require_once 'Mail/mimeDecode.php';
authenticate();
ini_set("memory_limit",MEMORY_LIMIT);

if(!isset($_GET['id'])) {
 die("No input Message ID");
} else {
 // See if message is local
 if(!($host = @mysql_result(dbquery("SELECT hostname FROM maillog WHERE id='".mysql_escape_string($_GET['id'])."'"),0))) {
  die("Message '".$_GET['id']."' not found\n");
 }
 if(!is_local($host) || RPC_ONLY) {
  // Host is remote - use XML-RPC
  //$client = new xmlrpc_client(constant('RPC_RELATIVE_PATH').'/rpcserver.php',$host,80);
  $input = new xmlrpcval($_GET['id']);
  $parameters = array($input);
  $msg = new xmlrpcmsg('return_quarantined_file',$parameters);
  //$rsp = $client->send($msg);
  $rsp = xmlrpc_wrapper($host,$msg);
  if($rsp->faultcode()==0) {
   $response = xmlrpc_decode($rsp->value());
  } else {
   die("Error: ".$rsp->faultstring());
  }
  $file = base64_decode($response);
 } else {
  $date = @mysql_result(dbquery("SELECT DATE_FORMAT(date,'%Y%m%d') FROM maillog where id='".mysql_escape_string($_GET['id'])."'"),0);
  $qdir = get_conf_var('QuarantineDir');
  switch(true) {
   case (file_exists($qdir.'/'.$date.'/nonspam/'.$_GET['id'])):
    $_GET['filename'] = $date.'/nonspam/'.$_GET['id'];
    break;
   case (file_exists($qdir.'/'.$date.'/spam/'.$_GET['id'])):
    $_GET['filename'] = $date.'/spam/'.$_GET['id'];
    break;
   case (file_exists($qdir.'/'.$date.'/mcp/'.$_GET['id'])):
    $_GET['filename'] = $date.'/mcp/'.$_GET['id'];
    break;
   case (file_exists($qdir.'/'.$date.'/'.$_GET['id'].'/message')):
    $_GET['filename'] = $date.'/'.$_GET['id'].'/message';
    break;
  }

  // File is local
  if(!isset($_GET['filename'])) {
   die("No input filename");
  } else {
   // SECURITY - strip off any potential nasties
   $_GET['filename'] = preg_replace('[\.\/|\.\.\/]','',$_GET['filename']);
   $filename = get_conf_var('QuarantineDir')."/".$_GET['filename'];
   if(!@file_exists($filename)) {
    die("Error: file not found\n");
   }
   $file = file_get_contents($filename);
  }
 }
}

$params['include_bodies'] = true;
$params['decode_bodies'] = true;
$params['decode_headers'] = true;
$params['input'] = $file;

$structure = Mail_mimeDecode::decode($params);
$mime_struct = Mail_mimeDecode::getMimeNumbers($structure);

// Make sure that part being requested actually exists
if(isset($_GET['part'])) {
 if(!isset($mime_struct[$_GET['part']])) {
  die("Part ".$_GET['part']." not found\n");
 }
}

function decode_structure($structure) {
 $type = $structure->ctype_primary."/".$structure->ctype_secondary;
 switch($type) {
  case "text/plain":
   echo "<html>\n";
   echo " <head>\n";
   echo " <title>Quarantined E-Mail Viewer</title>\n";
   echo " </head>\n";
   echo " <body>\n";
   echo " <pre>\n";
   echo htmlentities(wordwrap($structure->body));
   echo " </pre>\n";
   echo " </body>\n";
   echo "</html>\n";
   break;
  case "text/html":
   if(STRIP_HTML) {
    echo strip_tags($structure->body, ALLOWED_TAGS);
   } else {
    echo $structure->body;
   }
   break;
  case "multipart/alternative":
   break;
  default:
   header("Content-type: ".$structure->headers['content-type']);
   header("Content-Disposition: ".$structure->headers['content-disposition']);
   echo $structure->body;
   break;
 }
}

decode_structure($mime_struct[$_GET['part']]);
?>
