<?
/*
 MailWatch for MailScanner 0.3
 Copyright (C) 2003  Steve Freegard (smf@f2s.com)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

require("./functions.php");
require("./filter.inc");
session_start();
authenticate();

$filter=report_start("MRTG Style Mail Report");

$sql_last24hrs = "
 SELECT 
  DATE_FORMAT(timestamp, '%H:%i %d/%m') AS xaxis,
  COUNT(*) AS total_mail,
  SUM(virusinfected) AS total_virii,
  SUM(isspam) AS total_spam,
  SUM(size) AS total_size
 FROM 
  maillog
 WHERE
  1=1
 AND
  timestamp BETWEEN (NOW() - INTERVAL 24 HOUR) AND NOW() 
".$filter->CreateSQL()."
 GROUP BY
  xaxis
 ORDER BY
  timestamp DESC
";

dbtable($sql_last24hrs);

# JPGraph
include("./jpgraph/src/jpgraph.php");
include("./jpgraph/src/jpgraph_log.php");
include("./jpgraph/src/jpgraph_bar.php");
include("./jpgraph/src/jpgraph_line.php");

$result = dbquery($sql_last24hrs);
$last = "";
while($row=mysql_fetch_object($result)) {
 if($last==substr($row->xaxis,0,2)) {
  $data_labels_hour[] = "";
 } else {
  $data_labels_hour[] = substr($row->xaxis,0,2);
  $last = substr($row->xaxis,0,2);
 }
 $data_labels[] = $row->xaxis;
 $data_total_mail[] = $row->total_mail;
 $data_total_virii[] = $row->total_virii;
 $data_total_spam[] = $row->total_spam;
 $data_total_size[] = $row->total_size;
}

format_report_volume($data_total_size, $size_info);

$graph = new Graph(750,350,"mrtg_style.png",0,false);
//$graph->SetShadow();
$graph->SetScale("textlin");
//$graph->SetY2Scale("lin");
//$graph->y2axis->title->Set("Volume (".$size_info['longdesc'].")");
$graph->yaxis->SetTitleMargin(40);
$graph->img->SetMargin(60,60,30,70);
$graph->title->Set("Last 24 Hrs");
$graph->xaxis->title->Set("Date");
//$graph->xaxis->SetTextLabelInterval(60);
$graph->xaxis->SetTickLabels($data_labels_hour);
//$graph->xaxis->SetLabelAngle(45);
$graph->yaxis->title->Set("No. of messages");
$graph->legend->SetLayout(LEGEND_HOR);
$graph->legend->Pos(0.52,0.87,'center');
$bar1 = new LinePlot($data_total_mail);
$bar1->SetColor('blue');
$bar1->SetFillColor('blue');
$bar1->SetLegend('Mail');
$bar2 = new LinePlot($data_total_virii);
$bar2->SetColor('red');
$bar2->SetFillColor('red');
$bar2->SetLegend('Virii');
$bar3 = new LinePlot($data_total_spam);
$bar3->SetColor('pink');
$bar3->SetFillColor('pink');
$bar3->SetLegend('Spam');

$line1 = new LinePlot($data_total_size);
//$line1->SetColor('green');
$line1->SetFillColor('green');
$line1->SetLegend('Volume ('.$size_info['shortdesc'].')');
$line1->SetCenter();

//$abar1 = new AccBarPlot(array($bar2,$bar3));
//$gbplot = new GroupBarPlot(array($bar1,$abar1));

$graph->Add($bar1);
$graph->Add($bar2);
$graph->Add($bar3);
//$graph->Add($gbplot);
$graph->Stroke();

echo "<TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 HEIGHT=100% WIDTH=100%>\n";
echo " <TR><TD ALIGN=\"CENTER\"><IMG SRC=\"./images/mailscannerlogo.gif\"></TD></TR>\n";
echo " <TR>\n";
echo " <TD ALIGN=\"CENTER\"><IMG SRC=\"images/cache/mrtg_style.png?".time()."\"></TD>\n";
echo " </TR>\n";
echo " <TR>\n";
echo "  <TD ALIGN=\"CENTER\">\n";
echo "<TABLE BORDER=0 WIDTH=500>\n";
echo " <THEAD BGCOLOR=\"#F7CE4A\">\n";
echo "  <TH>Date</TH>\n";
echo "  <TH>Mail</TH>\n";
echo "  <TH>Spam</TH>\n";
echo "  <TH>Virus</TH>\n";
echo "  <TH>Volume</TH>\n";
echo " </THEAD>\n";
for($i=0; $i<count($data_total_mail); $i++) {
 echo "<TR BGCOLOR=\"#EBEBEB\">\n";
 echo " <TD ALIGN=\"CENTER\">$data_labels[$i]</TD>\n";
 echo " <TD ALIGN=\"RIGHT\">".number_format($data_total_mail[$i])."</TD>\n";
 echo " <TD ALIGN=\"RIGHT\">".number_format($data_total_spam[$i])."</TD>\n";
 echo " <TD ALIGN=\"RIGHT\">".number_format($data_total_virii[$i])."</TD>\n";
 echo " <TD ALIGN=\"RIGHT\">".format_mail_size($data_total_size[$i]*$size_info['formula'])."&nbsp;&nbsp;</TD>\n";
 echo "</TR>\n";
}
echo "</TABLE>\n";



html_end();
?>
