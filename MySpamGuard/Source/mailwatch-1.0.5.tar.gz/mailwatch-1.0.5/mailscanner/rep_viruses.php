<?
/*
 MailWatch for MailScanner
 Copyright (C) 2003  Steve Freegard (smf@f2s.com)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

require('./functions.php');
require('./filter.inc');
authenticate();
$filter=report_start("Virus Report");

// Get a list of virus scanners from MailScanner.conf
$scanner=array();
$scanners = explode(" ",get_conf_var("virusscanners"));
foreach($scanners as $vscanner) {
 switch ($vscanner) {
  case("sophos"):
   $scanner[$vscanner]['name'] = "Sophos";
   $scanner[$vscanner]['regexp'] = "/(>>>) Virus \'(\S+)\' found/";
   break;
  case("sophossavi"):
   $scanner[$vscanner]['name'] = "Sophos SAVI";
   $scanner[$vscanner]['regexp'] = "/(\S+) was infected by (\S+)/";
   break;
  case("clamav"):
   $scanner[$vscanner]['name'] = "ClamAV";
   $scanner[$vscanner]['regexp'] = "/(.+) contains (\S+)/";
   break;
  case("clamd"):
   $scanner[$vscanner]['name']  = "ClamD";
   $scanner[$vscanner]['regexp'] = "/(.+) contains (\S+)/";
   break;
  case("clamavmodule"):
   $scanner[$vscanner]['name'] = "Clam AV Module";
   $scanner[$vscanner]['regexp'] = "/(.+) was infected: (\S+)/";
   break;
  case("f-prot"):
   $scanner[$vscanner]['name'] = "F-Prot";
   $scanner[$vscanner]['regexp'] = "/(.+) Infection: (\S+)/";
   break;
  case("mcafee"):
   $scanner[$vscanner]['name'] = "McAfee";
   $scanner[$vscanner]['regexp'] = "/(.+) Found the (\S+) virus !!!/";
   break;
  case("f-secure"):
   $scanner[$vscanner]['name'] = "F-Secure";
   $scanner[$vscanner]['regexp'] = "/(.+) Infected: (\S+)/";
   break;
  case("trend"):
   $scanner[$vscanner]['name'] = "Trend";
   $scanner[$vscanner]['regexp'] = "/(Found virus) (\S+) in file (\S+)/";
   break;
  case("bitdefender"):
   $scanner[$vscanner]['name'] = "BitDefender";
   $scanner[$vscanner]['regexp'] = "/(.+) Found virus (\S+)/";
   break;
  case("kaspersky-4.5"):
   $scanner[$vscanner]['name'] = "Kaspersky";
   $scanner[$vscanner]['regexp'] = "/(.+) INFECTED (\S+)/";
   break;
  case("etrust"):
   $scanner[$vscanner]['name'] = "E-Trust";
   $scanner[$vscanner]['regexp'] = "/(\S+) is infected by virus: (\S+)/";
   break;
  case("avg"):
   $scanner[$vscanner]['name'] = "AVG";
   $scanner[$vscanner]['regexp'] = "/(Found virus) (\S+) in file (\S+)/";
   break;
  case("norman"):
   $scanner[$vscanner]['name'] = "Norman";
   $scanner[$vscanner]['regexp'] = "/(Found virus) (\S+) in file (\S+)/";
   break;
  case("nod32-1.99"):
   $scanner[$vscanner]['name'] = "NOD32';
   $scanner[$vscanner]['regexp'] = '/(Found virus) (\S+) in (\S+)/";
   break;
  case("antivir"):
   $scanner[$vscanner]['name'] = "AntiVir";
   $scanner[$vscanner]['regexp'] = "/(ALERT:) \[(\S+) \S+\]/";
   break;
 }
}

$sql = "
SELECT 
 DATE_FORMAT(timestamp, '".DATE_FORMAT." ".TIME_FORMAT."') as timestamp,
 report 
FROM 
 maillog 
WHERE 
 virusinfected = 1
AND
 report IS NOT NULL 
".$filter->CreateSQL()."
ORDER BY
 date ASC, time ASC";

$result = dbquery($sql);
if(!mysql_num_rows($result) > 0) {
 die("Error: no rows retrieved from database\n");
}


$virus_array = array();
 
while($row = mysql_fetch_object($result)) {
 foreach($scanner as $scan => $vals) {
  if (preg_match($vals['regexp'], $row->report, $virus_report)) {
   $virus = $virus_report[2];
   if(!isset($virus_array[$virus])) {
    $virus_array[$virus]['first_seen'] = $row->timestamp;
    $virus_array[$virus]['scanner'] = $vals['name'];
   }
   $virus_array[$virus]['count']++;
  }
 }
}

reset($virus_array);

while((list($key, $val) = each($virus_array))) { 
 $data[] = $val['count'];
 $data_names[] = "$key";
 $data_first_seen[] = $val['first_seen'];
 $data_scanner[] = $val['scanner'];
 $count++;
}

?>
<TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 HEIGHT=100% WIDTH=100%>
<TR>
 <TD ALIGN="CENTER"><IMG SRC="images/mailscannerlogo.gif"></TD>
</TR>
<TR>
 <TD ALIGN="CENTER">
  <TABLE WIDTH=500>
   <THEAD BGCOLOR="#F7CE4A">
    <TH>Virus</TH>
    <TH>Scanner</TH>
    <TH>First Seen</TH>
    <TH>Count</TH>
   </THEAD> 
<?
for($i=0; $i<count($data_names); $i++) {
 echo "<TR BGCOLOR=\"#EBEBEB\">
 <TD>$data_names[$i]</TD>
 <TD>$data_scanner[$i]</TD>
 <TD ALIGN=\"RIGHT\">$data_first_seen[$i]</TD>
 <TD ALIGN=\"RIGHT\">".number_format($data[$i])."</TD>
</TR>\n";
}
?>
  </TABLE>
 </TD>
</TR>
</TABLE>
