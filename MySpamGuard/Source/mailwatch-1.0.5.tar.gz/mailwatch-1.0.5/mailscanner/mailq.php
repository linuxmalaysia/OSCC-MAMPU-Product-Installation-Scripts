<?
require "./functions.php";
authenticate('A');
html_start("Mail Queue Viewer");

switch($_GET['queue']) {
 case "inq":
  $queue=inq;
  $display='Inbound Mail Queue';
  break;;
 case "outq":
  $queue=outq;
  $display='Outbound Mail Queue';
  break;;
 default:
  die("No queue specified\n");
  break;
}

db_colorised_table("
SELECT  
 id AS id2,
 CONCAT(DATE_FORMAT(cdate, '".DATE_FORMAT."'),' ',ctime) AS datetime,
 hostname,
 from_address,
 to_address,
 subject,
 message,
 size,
 attempts,
 CASE WHEN lastattempt=0 THEN '00:00:00' ELSE SEC_TO_TIME((UNIX_TIMESTAMP() - lastattempt)) END AS lastattempt 
FROM 
 ".$queue."
WHERE
 ".$GLOBALS['global_filter']."
ORDER BY
 cdate, ctime",$display,true,true);

html_end();
?>
