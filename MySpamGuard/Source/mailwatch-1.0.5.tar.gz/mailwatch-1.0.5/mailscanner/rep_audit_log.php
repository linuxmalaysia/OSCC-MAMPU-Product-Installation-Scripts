<?
/*
 MailWatch for MailScanner
 Copyright (C) 2003  Steve Freegard (smf@f2s.com)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

require("./functions.php");
require("./filter.inc");
session_start();
authenticate('A');

$filter=report_start("Audit Log",false,false);

$sql = "
 SELECT 
  DATE_FORMAT(a.timestamp,'".DATE_FORMAT." ".TIME_FORMAT."') AS 'Date/Time', 
  b.fullname AS 'User', 
  a.ip_address AS 'IP Address', 
  a.action AS 'Action' 
 FROM 
  audit_log a, 
  users b 
 WHERE 
  a.user=b.username 
 AND
  1=1
".$filter->CreateMtalogSQL()."
 ORDER BY timestamp DESC";

echo "<TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 HEIGHT=100% WIDTH=100%>\n";
echo " <TR><TD ALIGN=\"CENTER\"><IMG SRC=\"./images/mailscannerlogo.gif\"></TD></TR>\n";
echo " <TR><TD>\n";

dbtable($sql);

echo " </TD></TR>\n";

html_end();
?>
