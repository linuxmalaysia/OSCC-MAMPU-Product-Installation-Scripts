grant all privileges on db_nagiosql_v3.* to nagiosql_user@localhost identified by 'nagiosql_pass'
