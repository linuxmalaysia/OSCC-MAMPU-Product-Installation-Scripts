-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: glpi
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `glpi_alerts`
--

DROP TABLE IF EXISTS `glpi_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_alerts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `device_type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `FK_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php ALERT_* constant',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `alert` (`device_type`,`FK_device`,`type`),
  KEY `FK_device` (`FK_device`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_alerts`
--

LOCK TABLES `glpi_alerts` WRITE;
/*!40000 ALTER TABLE `glpi_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_auth_ldap`
--

DROP TABLE IF EXISTS `glpi_auth_ldap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_auth_ldap` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_rootdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_pass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '389',
  `ldap_condition` text COLLATE utf8_unicode_ci,
  `ldap_login` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid',
  `ldap_use_tls` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_group` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_group_condition` text COLLATE utf8_unicode_ci,
  `ldap_search_for_groups` int(11) NOT NULL DEFAULT '0',
  `ldap_field_group_member` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_comments` text COLLATE utf8_unicode_ci,
  `use_dn` int(1) NOT NULL DEFAULT '1',
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_opt_deref` int(1) NOT NULL DEFAULT '0',
  `ldap_field_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_field_language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_auth_ldap`
--

LOCK TABLES `glpi_auth_ldap` WRITE;
/*!40000 ALTER TABLE `glpi_auth_ldap` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_auth_ldap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_auth_ldap_replicate`
--

DROP TABLE IF EXISTS `glpi_auth_ldap_replicate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_auth_ldap_replicate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_auth_ldap (ID)',
  `ldap_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_port` int(11) NOT NULL DEFAULT '389',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_auth_ldap_replicate`
--

LOCK TABLES `glpi_auth_ldap_replicate` WRITE;
/*!40000 ALTER TABLE `glpi_auth_ldap_replicate` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_auth_ldap_replicate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_auth_mail`
--

DROP TABLE IF EXISTS `glpi_auth_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_auth_mail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imap_auth_server` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imap_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_auth_mail`
--

LOCK TABLES `glpi_auth_mail` WRITE;
/*!40000 ALTER TABLE `glpi_auth_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_auth_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_bookmark`
--

DROP TABLE IF EXISTS `glpi_bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_bookmark` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `device_type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `private` smallint(6) NOT NULL DEFAULT '1',
  `FK_entities` int(11) NOT NULL DEFAULT '-1' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` smallint(6) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `FK_users` (`FK_users`),
  KEY `private` (`private`),
  KEY `device_type` (`device_type`),
  KEY `recursive` (`recursive`),
  KEY `FK_entities` (`FK_entities`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_bookmark`
--

LOCK TABLES `glpi_bookmark` WRITE;
/*!40000 ALTER TABLE `glpi_bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_cartridges`
--

DROP TABLE IF EXISTS `glpi_cartridges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_cartridges` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_glpi_cartridges_type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_cartridges_type (ID)',
  `FK_glpi_printers` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_printers (ID)',
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_cartridges_type` (`FK_glpi_cartridges_type`),
  KEY `FK_glpi_printers` (`FK_glpi_printers`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_cartridges`
--

LOCK TABLES `glpi_cartridges` WRITE;
/*!40000 ALTER TABLE `glpi_cartridges` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_cartridges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_cartridges_assoc`
--

DROP TABLE IF EXISTS `glpi_cartridges_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_cartridges_assoc` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_glpi_cartridges_type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_cartridges_type (ID)',
  `FK_glpi_dropdown_model_printers` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model_printers (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_glpi_type_printer` (`FK_glpi_dropdown_model_printers`,`FK_glpi_cartridges_type`),
  KEY `FK_glpi_cartridges_type` (`FK_glpi_cartridges_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_cartridges_assoc`
--

LOCK TABLES `glpi_cartridges_assoc` WRITE;
/*!40000 ALTER TABLE `glpi_cartridges_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_cartridges_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_cartridges_type`
--

DROP TABLE IF EXISTS `glpi_cartridges_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_cartridges_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_cartridge_type (ID)',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `alarm` smallint(6) NOT NULL DEFAULT '10',
  `notes` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `location` (`location`),
  KEY `type` (`type`),
  KEY `alarm` (`alarm`),
  KEY `FK_entities` (`FK_entities`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_cartridges_type`
--

LOCK TABLES `glpi_cartridges_type` WRITE;
/*!40000 ALTER TABLE `glpi_cartridges_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_cartridges_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_computer_device`
--

DROP TABLE IF EXISTS `glpi_computer_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_computer_device` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `specificity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_DEVICE constant',
  `FK_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `FK_computers` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  PRIMARY KEY (`ID`),
  KEY `FK_computers` (`FK_computers`),
  KEY `FK_device` (`FK_device`),
  KEY `specificity` (`specificity`),
  KEY `device_type` (`device_type`,`FK_device`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_computer_device`
--

LOCK TABLES `glpi_computer_device` WRITE;
/*!40000 ALTER TABLE `glpi_computer_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_computer_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_computerdisks`
--

DROP TABLE IF EXISTS `glpi_computerdisks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_computerdisks` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_computers` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mountpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FK_filesystems` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_filesystems (ID)',
  `totalsize` int(11) NOT NULL DEFAULT '0',
  `freesize` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `name` (`name`),
  KEY `FK_filesystems` (`FK_filesystems`),
  KEY `FK_computers` (`FK_computers`),
  KEY `device` (`device`),
  KEY `mountpoint` (`mountpoint`),
  KEY `totalsize` (`totalsize`),
  KEY `freesize` (`freesize`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_computerdisks`
--

LOCK TABLES `glpi_computerdisks` WRITE;
/*!40000 ALTER TABLE `glpi_computerdisks` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_computerdisks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_computers`
--

DROP TABLE IF EXISTS `glpi_computers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_computers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `os` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_os (ID)',
  `os_version` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_os_version (ID)',
  `os_sp` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_os_sp (ID)',
  `os_license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_license_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auto_update` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_auto_update (ID)',
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `domain` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_domain (ID)',
  `network` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_network (ID)',
  `model` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_type_computers (ID)',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `notes` longtext COLLATE utf8_unicode_ci,
  `ocs_import` smallint(6) NOT NULL DEFAULT '0',
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `location` (`location`),
  KEY `os` (`os`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `date_mod` (`date_mod`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `model` (`model`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `os_sp` (`os_sp`),
  KEY `os_version` (`os_version`),
  KEY `network` (`network`),
  KEY `domain` (`domain`),
  KEY `auto_update` (`auto_update`),
  KEY `ocs_import` (`ocs_import`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_computers`
--

LOCK TABLES `glpi_computers` WRITE;
/*!40000 ALTER TABLE `glpi_computers` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_computers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_config`
--

DROP TABLE IF EXISTS `glpi_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_config` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `num_of_events` int(11) NOT NULL DEFAULT '10',
  `jobs_at_login` smallint(6) NOT NULL DEFAULT '0',
  `sendexpire` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cut` int(11) NOT NULL DEFAULT '255',
  `expire_events` int(11) NOT NULL DEFAULT '30',
  `list_limit` int(11) NOT NULL DEFAULT '20',
  `list_limit_max` int(11) NOT NULL DEFAULT '50',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logotxt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_loglevel` smallint(6) NOT NULL DEFAULT '5',
  `mailing` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mailing_signature` text COLLATE utf8_unicode_ci,
  `permit_helpdesk` smallint(6) NOT NULL DEFAULT '0',
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'en_GB' COMMENT 'see define.php CFG_GLPI[language] array',
  `priority_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT '#fff2f2',
  `priority_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT '#ffe0e0',
  `priority_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT '#ffcece',
  `priority_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT '#ffbfbf',
  `priority_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT '#ffadad',
  `date_fiscale` date NOT NULL DEFAULT '2005-12-31',
  `cartridges_alarm` int(11) NOT NULL DEFAULT '10',
  `cas_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cas_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cas_uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cas_logout` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extra_ldap_server` int(11) NOT NULL DEFAULT '1' COMMENT 'RELATION to glpi_auth_ldap (ID)',
  `existing_auth_server_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `existing_auth_server_field_clean_domain` smallint(6) NOT NULL DEFAULT '0',
  `planning_begin` time NOT NULL DEFAULT '08:00:00',
  `planning_end` time NOT NULL DEFAULT '20:00:00',
  `utf8_conv` int(11) NOT NULL DEFAULT '0',
  `auto_assign` smallint(6) NOT NULL DEFAULT '0',
  `public_faq` smallint(6) NOT NULL DEFAULT '0',
  `url_base` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_in_mail` smallint(6) NOT NULL DEFAULT '0',
  `text_login` text COLLATE utf8_unicode_ci,
  `auto_update_check` smallint(6) NOT NULL DEFAULT '0',
  `founded_new_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dropdown_max` int(11) NOT NULL DEFAULT '100',
  `ajax_wildcard` char(1) COLLATE utf8_unicode_ci DEFAULT '*',
  `use_ajax` smallint(6) NOT NULL DEFAULT '0',
  `ajax_limit_count` int(11) NOT NULL DEFAULT '50',
  `ajax_autocompletion` smallint(6) NOT NULL DEFAULT '1',
  `auto_add_users` smallint(6) NOT NULL DEFAULT '1',
  `dateformat` smallint(6) NOT NULL DEFAULT '0',
  `numberformat` smallint(6) NOT NULL DEFAULT '0',
  `nextprev_item` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'name',
  `view_ID` smallint(6) NOT NULL DEFAULT '0',
  `dropdown_limit` int(11) NOT NULL DEFAULT '50',
  `ocs_mode` smallint(6) NOT NULL DEFAULT '0',
  `use_cache` smallint(6) NOT NULL DEFAULT '1',
  `cache_max_size` int(11) NOT NULL DEFAULT '20',
  `smtp_mode` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php MAIL_* constant',
  `smtp_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_port` int(11) NOT NULL DEFAULT '25',
  `smtp_username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proxy_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proxy_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '8080',
  `proxy_user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `proxy_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `followup_on_update_ticket` smallint(6) NOT NULL DEFAULT '1',
  `contract_alerts` smallint(6) NOT NULL DEFAULT '0',
  `infocom_alerts` smallint(6) NOT NULL DEFAULT '0',
  `licenses_alert` smallint(6) NOT NULL DEFAULT '0',
  `cartridges_alert` int(11) NOT NULL DEFAULT '0',
  `consumables_alert` int(11) NOT NULL DEFAULT '0',
  `keep_tracking_on_delete` int(11) DEFAULT '1',
  `show_admin_doc` int(11) DEFAULT '0',
  `time_step` int(11) DEFAULT '5',
  `decimal_number` int(11) DEFAULT '2',
  `helpdeskhelp_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `centralhelp_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `default_rubdoc_tracking` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_rubdocs (ID)',
  `monitors_management_restrict` int(1) NOT NULL DEFAULT '2',
  `phones_management_restrict` int(1) NOT NULL DEFAULT '2',
  `peripherals_management_restrict` int(1) NOT NULL DEFAULT '2',
  `printers_management_restrict` int(1) NOT NULL DEFAULT '2',
  `licenses_management_restrict` int(1) NOT NULL DEFAULT '2',
  `license_deglobalisation` int(1) NOT NULL DEFAULT '1',
  `use_errorlog` int(1) NOT NULL DEFAULT '0',
  `glpi_timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autoupdate_link_contact` smallint(6) NOT NULL DEFAULT '1',
  `autoupdate_link_user` smallint(6) NOT NULL DEFAULT '1',
  `autoupdate_link_group` smallint(6) NOT NULL DEFAULT '1',
  `autoupdate_link_location` smallint(6) NOT NULL DEFAULT '1',
  `autoupdate_link_state` smallint(6) NOT NULL DEFAULT '0',
  `autoclean_link_contact` smallint(6) NOT NULL DEFAULT '0',
  `autoclean_link_user` smallint(6) NOT NULL DEFAULT '0',
  `autoclean_link_group` smallint(6) NOT NULL DEFAULT '0',
  `autoclean_link_location` smallint(6) NOT NULL DEFAULT '0',
  `autoclean_link_state` smallint(6) NOT NULL DEFAULT '0',
  `flat_dropdowntree` smallint(6) NOT NULL DEFAULT '0',
  `autoname_entity` smallint(6) NOT NULL DEFAULT '1',
  `expand_soft_categorized` int(1) NOT NULL DEFAULT '1',
  `expand_soft_not_categorized` int(1) NOT NULL DEFAULT '1',
  `dbreplicate_notify_desynchronization` smallint(6) NOT NULL DEFAULT '0',
  `dbreplicate_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dbreplicate_maxdelay` int(11) NOT NULL DEFAULT '3600',
  `category_on_software_delete` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_software_category (ID)',
  `x509_email_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_title_mandatory` int(1) NOT NULL DEFAULT '0',
  `ticket_content_mandatory` int(1) NOT NULL DEFAULT '1',
  `ticket_category_mandatory` int(1) NOT NULL DEFAULT '0',
  `mailgate_filesize_max` int(11) NOT NULL DEFAULT '2097152',
  `tracking_order` smallint(6) NOT NULL DEFAULT '0',
  `followup_private` smallint(6) NOT NULL DEFAULT '0',
  `software_helpdesk_visible` int(1) NOT NULL DEFAULT '1',
  `name_display_order` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_config`
--

LOCK TABLES `glpi_config` WRITE;
/*!40000 ALTER TABLE `glpi_config` DISABLE KEYS */;
INSERT INTO `glpi_config` VALUES (1,10,0,'1',250,30,15,50,' 0.72.3','GLPI powered by indepnet',5,'0','admsys@xxxxx.fr',NULL,'SIGNATURE',0,'en_GB','#fff2f2','#ffe0e0','#ffcece','#ffbfbf','#ffadad','2005-12-31',10,'','','',NULL,1,NULL,0,'08:00:00','20:00:00',1,0,0,'http://localhost/glpi/',0,'',0,'',100,'*',0,50,1,1,0,0,'name',0,50,1,1,20,0,NULL,25,NULL,NULL,NULL,'8080',NULL,NULL,1,0,0,0,0,0,0,0,5,2,NULL,NULL,0,2,2,2,2,2,1,0,'0',1,1,1,1,0,0,0,0,0,0,0,1,1,1,0,NULL,3600,1,NULL,0,1,0,2097152,0,0,1,0);
/*!40000 ALTER TABLE `glpi_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_connect_wire`
--

DROP TABLE IF EXISTS `glpi_connect_wire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_connect_wire` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `end1` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to type (ID)',
  `end2` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  `type` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `connect` (`end1`,`end2`,`type`),
  KEY `end2` (`end2`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_connect_wire`
--

LOCK TABLES `glpi_connect_wire` WRITE;
/*!40000 ALTER TABLE `glpi_connect_wire` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_connect_wire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_consumables`
--

DROP TABLE IF EXISTS `glpi_consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_consumables` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_glpi_consumables_type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_consumables_type (ID)',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `id_user` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_cartridges_type` (`FK_glpi_consumables_type`),
  KEY `date_in` (`date_in`),
  KEY `date_out` (`date_out`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_consumables`
--

LOCK TABLES `glpi_consumables` WRITE;
/*!40000 ALTER TABLE `glpi_consumables` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_consumables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_consumables_type`
--

DROP TABLE IF EXISTS `glpi_consumables_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_consumables_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_consumable_type (ID)',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `alarm` int(11) NOT NULL DEFAULT '10',
  `notes` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `location` (`location`),
  KEY `type` (`type`),
  KEY `alarm` (`alarm`),
  KEY `FK_entities` (`FK_entities`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_consumables_type`
--

LOCK TABLES `glpi_consumables_type` WRITE;
/*!40000 ALTER TABLE `glpi_consumables_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_consumables_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_contact_enterprise`
--

DROP TABLE IF EXISTS `glpi_contact_enterprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_contact_enterprise` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_enterprises (ID)',
  `FK_contact` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_contacts (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_enterprise` (`FK_enterprise`,`FK_contact`),
  KEY `FK_contact` (`FK_contact`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_contact_enterprise`
--

LOCK TABLES `glpi_contact_enterprise` WRITE;
/*!40000 ALTER TABLE `glpi_contact_enterprise` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_contact_enterprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_contacts`
--

DROP TABLE IF EXISTS `glpi_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_contacts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_contact_type (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `notes` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `FK_entities` (`FK_entities`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_contacts`
--

LOCK TABLES `glpi_contacts` WRITE;
/*!40000 ALTER TABLE `glpi_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_contract_device`
--

DROP TABLE IF EXISTS `glpi_contract_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_contract_device` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_contract` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_contracts (ID)',
  `FK_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_contract_device` (`FK_contract`,`device_type`,`FK_device`),
  KEY `FK_device` (`FK_device`,`device_type`),
  KEY `device_type` (`device_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_contract_device`
--

LOCK TABLES `glpi_contract_device` WRITE;
/*!40000 ALTER TABLE `glpi_contract_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_contract_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_contract_enterprise`
--

DROP TABLE IF EXISTS `glpi_contract_enterprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_contract_enterprise` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_enterprises (ID)',
  `FK_contract` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_contracts (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_enterprise` (`FK_enterprise`,`FK_contract`),
  KEY `FK_contract` (`FK_contract`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_contract_enterprise`
--

LOCK TABLES `glpi_contract_enterprise` WRITE;
/*!40000 ALTER TABLE `glpi_contract_enterprise` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_contract_enterprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_contracts`
--

DROP TABLE IF EXISTS `glpi_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_contracts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `contract_type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_contract_type (ID)',
  `begin_date` date DEFAULT NULL,
  `duration` smallint(6) NOT NULL DEFAULT '0',
  `notice` smallint(6) NOT NULL DEFAULT '0',
  `periodicity` smallint(6) NOT NULL DEFAULT '0',
  `facturation` smallint(6) NOT NULL DEFAULT '0',
  `bill_type` int(11) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `compta_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday` smallint(6) NOT NULL DEFAULT '0',
  `monday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `monday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `monday` smallint(6) NOT NULL DEFAULT '0',
  `device_countmax` int(11) NOT NULL DEFAULT '0',
  `notes` longtext COLLATE utf8_unicode_ci,
  `alert` smallint(6) NOT NULL DEFAULT '0',
  `renewal` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `contract_type` (`contract_type`),
  KEY `begin_date` (`begin_date`),
  KEY `bill_type` (`bill_type`),
  KEY `name` (`name`),
  KEY `FK_entities` (`FK_entities`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_contracts`
--

LOCK TABLES `glpi_contracts` WRITE;
/*!40000 ALTER TABLE `glpi_contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_case`
--

DROP TABLE IF EXISTS `glpi_device_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_case` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_case_type (ID)',
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_case`
--

LOCK TABLES `glpi_device_case` WRITE;
/*!40000 ALTER TABLE `glpi_device_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_control`
--

DROP TABLE IF EXISTS `glpi_device_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_control` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `raid` smallint(6) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_interface (ID)',
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_control`
--

LOCK TABLES `glpi_device_control` WRITE;
/*!40000 ALTER TABLE `glpi_device_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_drive`
--

DROP TABLE IF EXISTS `glpi_device_drive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_drive` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_writer` smallint(6) NOT NULL DEFAULT '1',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_interface (ID)',
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_drive`
--

LOCK TABLES `glpi_device_drive` WRITE;
/*!40000 ALTER TABLE `glpi_device_drive` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_drive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_gfxcard`
--

DROP TABLE IF EXISTS `glpi_device_gfxcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_gfxcard` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FK_interface` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_interface (ID)',
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_gfxcard`
--

LOCK TABLES `glpi_device_gfxcard` WRITE;
/*!40000 ALTER TABLE `glpi_device_gfxcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_gfxcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_hdd`
--

DROP TABLE IF EXISTS `glpi_device_hdd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_hdd` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rpm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_interface (ID)',
  `cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_hdd`
--

LOCK TABLES `glpi_device_hdd` WRITE;
/*!40000 ALTER TABLE `glpi_device_hdd` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_hdd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_iface`
--

DROP TABLE IF EXISTS `glpi_device_iface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_iface` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bandwidth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_iface`
--

LOCK TABLES `glpi_device_iface` WRITE;
/*!40000 ALTER TABLE `glpi_device_iface` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_iface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_moboard`
--

DROP TABLE IF EXISTS `glpi_device_moboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_moboard` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_moboard`
--

LOCK TABLES `glpi_device_moboard` WRITE;
/*!40000 ALTER TABLE `glpi_device_moboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_moboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_pci`
--

DROP TABLE IF EXISTS `glpi_device_pci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_pci` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_pci`
--

LOCK TABLES `glpi_device_pci` WRITE;
/*!40000 ALTER TABLE `glpi_device_pci` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_pci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_power`
--

DROP TABLE IF EXISTS `glpi_device_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_power` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `atx` smallint(6) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_power`
--

LOCK TABLES `glpi_device_power` WRITE;
/*!40000 ALTER TABLE `glpi_device_power` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_processor`
--

DROP TABLE IF EXISTS `glpi_device_processor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_processor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_processor`
--

LOCK TABLES `glpi_device_processor` WRITE;
/*!40000 ALTER TABLE `glpi_device_processor` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_processor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_ram`
--

DROP TABLE IF EXISTS `glpi_device_ram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_ram` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_ram_type (ID)',
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_ram`
--

LOCK TABLES `glpi_device_ram` WRITE;
/*!40000 ALTER TABLE `glpi_device_ram` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_ram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_device_sndcard`
--

DROP TABLE IF EXISTS `glpi_device_sndcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_device_sndcard` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `specif_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `designation` (`designation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_device_sndcard`
--

LOCK TABLES `glpi_device_sndcard` WRITE;
/*!40000 ALTER TABLE `glpi_device_sndcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_device_sndcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_display`
--

DROP TABLE IF EXISTS `glpi_display`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_display` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `num` smallint(6) NOT NULL DEFAULT '0',
  `rank` smallint(6) NOT NULL DEFAULT '0',
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `display` (`type`,`num`,`FK_users`),
  KEY `rank` (`rank`),
  KEY `num` (`num`),
  KEY `FK_users` (`FK_users`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_display`
--

LOCK TABLES `glpi_display` WRITE;
/*!40000 ALTER TABLE `glpi_display` DISABLE KEYS */;
INSERT INTO `glpi_display` VALUES (32,1,4,4,0),(34,1,45,6,0),(33,1,40,5,0),(31,1,5,3,0),(30,1,23,2,0),(86,12,3,1,0),(49,4,31,1,0),(50,4,23,2,0),(51,4,3,3,0),(52,4,4,4,0),(44,3,31,1,0),(38,2,31,1,0),(39,2,23,2,0),(45,3,23,2,0),(46,3,3,3,0),(63,6,4,3,0),(62,6,5,2,0),(61,6,23,1,0),(83,11,4,2,0),(82,11,34,1,0),(57,5,3,3,0),(56,5,23,2,0),(55,5,31,1,0),(29,1,31,1,0),(35,1,3,7,0),(36,1,19,8,0),(37,1,17,9,0),(40,2,3,3,0),(41,2,4,4,0),(42,2,11,6,0),(43,2,19,7,0),(47,3,4,4,0),(48,3,19,6,0),(53,4,19,6,0),(54,4,7,7,0),(58,5,4,4,0),(59,5,19,6,0),(60,5,7,7,0),(64,7,3,1,0),(65,7,4,2,0),(66,7,5,3,0),(67,7,6,4,0),(68,7,9,5,0),(69,8,9,1,0),(70,8,3,2,0),(71,8,4,3,0),(72,8,5,4,0),(73,8,10,5,0),(74,8,6,6,0),(75,10,4,1,0),(76,10,3,2,0),(77,10,5,3,0),(78,10,6,4,0),(79,10,7,5,0),(80,10,11,6,0),(84,11,23,3,0),(85,11,3,4,0),(88,12,6,2,0),(89,12,4,3,0),(90,12,5,4,0),(91,13,3,1,0),(92,13,4,2,0),(93,13,7,3,0),(94,13,5,4,0),(95,13,16,5,0),(96,15,34,1,0),(98,15,5,3,0),(99,15,6,4,0),(100,15,3,5,0),(101,17,34,1,0),(102,17,4,2,0),(103,17,23,3,0),(104,17,3,4,0),(105,2,40,5,0),(106,3,40,5,0),(107,4,40,5,0),(108,5,40,5,0),(109,15,8,6,0),(110,23,31,1,0),(111,23,23,2,0),(112,23,3,3,0),(113,23,4,4,0),(114,23,40,5,0),(115,23,19,6,0),(116,23,7,7,0),(117,27,16,1,0),(118,22,31,1,0),(119,29,4,1,0),(120,29,3,2,0),(121,35,80,1,0),(122,6,72,4,0),(123,6,163,5,0);
/*!40000 ALTER TABLE `glpi_display` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_display_default`
--

DROP TABLE IF EXISTS `glpi_display_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_display_default` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `device_type` int(11) NOT NULL COMMENT 'see define.php *_TYPE constant',
  `FK_bookmark` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_bookmark (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_users` (`FK_users`,`device_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_display_default`
--

LOCK TABLES `glpi_display_default` WRITE;
/*!40000 ALTER TABLE `glpi_display_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_display_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_doc_device`
--

DROP TABLE IF EXISTS `glpi_doc_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_doc_device` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_doc` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_docs (ID)',
  `FK_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_doc_device` (`FK_doc`,`device_type`,`FK_device`),
  KEY `FK_device` (`FK_device`,`device_type`),
  KEY `device_type` (`device_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_doc_device`
--

LOCK TABLES `glpi_doc_device` WRITE;
/*!40000 ALTER TABLE `glpi_doc_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_doc_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_docs`
--

DROP TABLE IF EXISTS `glpi_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_docs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rubrique` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_rubdocs (ID)',
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_tracking` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_tracking (ID)',
  PRIMARY KEY (`ID`),
  KEY `rubrique` (`rubrique`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `FK_users` (`FK_users`),
  KEY `FK_tracking` (`FK_tracking`),
  KEY `FK_entities` (`FK_entities`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_docs`
--

LOCK TABLES `glpi_docs` WRITE;
/*!40000 ALTER TABLE `glpi_docs` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_auto_update`
--

DROP TABLE IF EXISTS `glpi_dropdown_auto_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_auto_update` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_auto_update`
--

LOCK TABLES `glpi_dropdown_auto_update` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_auto_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_auto_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_budget`
--

DROP TABLE IF EXISTS `glpi_dropdown_budget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_budget` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_budget`
--

LOCK TABLES `glpi_dropdown_budget` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_budget` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_budget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_cartridge_type`
--

DROP TABLE IF EXISTS `glpi_dropdown_cartridge_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_cartridge_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_cartridge_type`
--

LOCK TABLES `glpi_dropdown_cartridge_type` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_cartridge_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_cartridge_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_case_type`
--

DROP TABLE IF EXISTS `glpi_dropdown_case_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_case_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_case_type`
--

LOCK TABLES `glpi_dropdown_case_type` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_case_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_case_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_consumable_type`
--

DROP TABLE IF EXISTS `glpi_dropdown_consumable_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_consumable_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_consumable_type`
--

LOCK TABLES `glpi_dropdown_consumable_type` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_consumable_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_consumable_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_contact_type`
--

DROP TABLE IF EXISTS `glpi_dropdown_contact_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_contact_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_contact_type`
--

LOCK TABLES `glpi_dropdown_contact_type` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_contact_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_contact_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_contract_type`
--

DROP TABLE IF EXISTS `glpi_dropdown_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_contract_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_contract_type`
--

LOCK TABLES `glpi_dropdown_contract_type` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_contract_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_contract_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_domain`
--

DROP TABLE IF EXISTS `glpi_dropdown_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_domain` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_domain`
--

LOCK TABLES `glpi_dropdown_domain` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_enttype`
--

DROP TABLE IF EXISTS `glpi_dropdown_enttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_enttype` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_enttype`
--

LOCK TABLES `glpi_dropdown_enttype` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_enttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_enttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_filesystems`
--

DROP TABLE IF EXISTS `glpi_dropdown_filesystems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_filesystems` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_filesystems`
--

LOCK TABLES `glpi_dropdown_filesystems` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_filesystems` DISABLE KEYS */;
INSERT INTO `glpi_dropdown_filesystems` VALUES (1,'ext',NULL),(2,'ext2',NULL),(3,'ext3',NULL),(4,'ext4',NULL),(5,'FAT',NULL),(6,'FAT32',NULL),(7,'VFAT',NULL),(8,'HFS',NULL),(9,'HPFS',NULL),(10,'HTFS',NULL),(11,'JFS',NULL),(12,'JFS2',NULL),(13,'NFS',NULL),(14,'NTFS',NULL),(15,'ReiserFS',NULL),(16,'SMBFS',NULL),(17,'UDF',NULL),(18,'UFS',NULL),(19,'XFS',NULL),(20,'ZFS',NULL);
/*!40000 ALTER TABLE `glpi_dropdown_filesystems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_firmware`
--

DROP TABLE IF EXISTS `glpi_dropdown_firmware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_firmware` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_firmware`
--

LOCK TABLES `glpi_dropdown_firmware` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_firmware` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_firmware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_iface`
--

DROP TABLE IF EXISTS `glpi_dropdown_iface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_iface` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_iface`
--

LOCK TABLES `glpi_dropdown_iface` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_iface` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_iface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_interface`
--

DROP TABLE IF EXISTS `glpi_dropdown_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_interface` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_interface`
--

LOCK TABLES `glpi_dropdown_interface` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_interface` DISABLE KEYS */;
INSERT INTO `glpi_dropdown_interface` VALUES (1,'IDE',NULL),(2,'SATA',NULL),(3,'SCSI',NULL),(4,'USB',NULL),(5,'AGP',''),(6,'PCI',''),(7,'PCIe',''),(8,'PCI-X','');
/*!40000 ALTER TABLE `glpi_dropdown_interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_kbcategories`
--

DROP TABLE IF EXISTS `glpi_dropdown_kbcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_kbcategories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `parentID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_kbcategories (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comments` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `parentID_2` (`parentID`,`name`),
  KEY `parentID` (`parentID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_kbcategories`
--

LOCK TABLES `glpi_dropdown_kbcategories` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_kbcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_kbcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_licensetypes`
--

DROP TABLE IF EXISTS `glpi_dropdown_licensetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_licensetypes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_licensetypes`
--

LOCK TABLES `glpi_dropdown_licensetypes` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_licensetypes` DISABLE KEYS */;
INSERT INTO `glpi_dropdown_licensetypes` VALUES (1,'OEM','');
/*!40000 ALTER TABLE `glpi_dropdown_licensetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_locations`
--

DROP TABLE IF EXISTS `glpi_dropdown_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_locations` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `completename` text COLLATE utf8_unicode_ci,
  `comments` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`,`parentID`,`FK_entities`),
  KEY `parentID` (`parentID`),
  KEY `FK_entities` (`FK_entities`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_locations`
--

LOCK TABLES `glpi_dropdown_locations` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_manufacturer`
--

DROP TABLE IF EXISTS `glpi_dropdown_manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_manufacturer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_manufacturer`
--

LOCK TABLES `glpi_dropdown_manufacturer` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_manufacturer` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_manufacturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_model`
--

DROP TABLE IF EXISTS `glpi_dropdown_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_model` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_model`
--

LOCK TABLES `glpi_dropdown_model` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_model_monitors`
--

DROP TABLE IF EXISTS `glpi_dropdown_model_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_model_monitors` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_model_monitors`
--

LOCK TABLES `glpi_dropdown_model_monitors` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_model_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_model_monitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_model_networking`
--

DROP TABLE IF EXISTS `glpi_dropdown_model_networking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_model_networking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_model_networking`
--

LOCK TABLES `glpi_dropdown_model_networking` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_model_networking` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_model_networking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_model_peripherals`
--

DROP TABLE IF EXISTS `glpi_dropdown_model_peripherals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_model_peripherals` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_model_peripherals`
--

LOCK TABLES `glpi_dropdown_model_peripherals` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_model_peripherals` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_model_peripherals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_model_phones`
--

DROP TABLE IF EXISTS `glpi_dropdown_model_phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_model_phones` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_model_phones`
--

LOCK TABLES `glpi_dropdown_model_phones` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_model_phones` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_model_phones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_model_printers`
--

DROP TABLE IF EXISTS `glpi_dropdown_model_printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_model_printers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_model_printers`
--

LOCK TABLES `glpi_dropdown_model_printers` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_model_printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_model_printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_netpoint`
--

DROP TABLE IF EXISTS `glpi_dropdown_netpoint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_netpoint` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `location` (`location`),
  KEY `name` (`name`),
  KEY `FK_entities` (`FK_entities`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_netpoint`
--

LOCK TABLES `glpi_dropdown_netpoint` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_netpoint` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_netpoint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_network`
--

DROP TABLE IF EXISTS `glpi_dropdown_network`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_network` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_network`
--

LOCK TABLES `glpi_dropdown_network` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_network` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_network` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_os`
--

DROP TABLE IF EXISTS `glpi_dropdown_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_os` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_os`
--

LOCK TABLES `glpi_dropdown_os` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_os_sp`
--

DROP TABLE IF EXISTS `glpi_dropdown_os_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_os_sp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_os_sp`
--

LOCK TABLES `glpi_dropdown_os_sp` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_os_sp` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_os_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_os_version`
--

DROP TABLE IF EXISTS `glpi_dropdown_os_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_os_version` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_os_version`
--

LOCK TABLES `glpi_dropdown_os_version` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_os_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_os_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_phone_power`
--

DROP TABLE IF EXISTS `glpi_dropdown_phone_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_phone_power` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_phone_power`
--

LOCK TABLES `glpi_dropdown_phone_power` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_phone_power` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_phone_power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_ram_type`
--

DROP TABLE IF EXISTS `glpi_dropdown_ram_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_ram_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_ram_type`
--

LOCK TABLES `glpi_dropdown_ram_type` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_ram_type` DISABLE KEYS */;
INSERT INTO `glpi_dropdown_ram_type` VALUES (1,'EDO',NULL),(2,'DDR',NULL),(3,'SDRAM',NULL),(4,'SDRAM-2',NULL);
/*!40000 ALTER TABLE `glpi_dropdown_ram_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_rubdocs`
--

DROP TABLE IF EXISTS `glpi_dropdown_rubdocs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_rubdocs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_rubdocs`
--

LOCK TABLES `glpi_dropdown_rubdocs` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_rubdocs` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_rubdocs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_software_category`
--

DROP TABLE IF EXISTS `glpi_dropdown_software_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_software_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_software_category`
--

LOCK TABLES `glpi_dropdown_software_category` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_software_category` DISABLE KEYS */;
INSERT INTO `glpi_dropdown_software_category` VALUES (1,'FUSION',NULL);
/*!40000 ALTER TABLE `glpi_dropdown_software_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_state`
--

DROP TABLE IF EXISTS `glpi_dropdown_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_state` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_state`
--

LOCK TABLES `glpi_dropdown_state` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_tracking_category`
--

DROP TABLE IF EXISTS `glpi_dropdown_tracking_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_tracking_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `parentID` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comments` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `name` (`name`),
  KEY `parentID` (`parentID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_tracking_category`
--

LOCK TABLES `glpi_dropdown_tracking_category` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_tracking_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_tracking_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_user_titles`
--

DROP TABLE IF EXISTS `glpi_dropdown_user_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_user_titles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_user_titles`
--

LOCK TABLES `glpi_dropdown_user_titles` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_user_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_user_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_user_types`
--

DROP TABLE IF EXISTS `glpi_dropdown_user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_user_types` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_user_types`
--

LOCK TABLES `glpi_dropdown_user_types` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_user_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_user_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_dropdown_vlan`
--

DROP TABLE IF EXISTS `glpi_dropdown_vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_dropdown_vlan` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_dropdown_vlan`
--

LOCK TABLES `glpi_dropdown_vlan` WRITE;
/*!40000 ALTER TABLE `glpi_dropdown_vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_dropdown_vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_enterprises`
--

DROP TABLE IF EXISTS `glpi_enterprises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_enterprises` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_enttype (ID)',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `FK_entities` (`FK_entities`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_enterprises`
--

LOCK TABLES `glpi_enterprises` WRITE;
/*!40000 ALTER TABLE `glpi_enterprises` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_enterprises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_entities`
--

DROP TABLE IF EXISTS `glpi_entities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_entities` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `completename` text COLLATE utf8_unicode_ci,
  `comments` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`,`parentID`),
  KEY `parentID` (`parentID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_entities`
--

LOCK TABLES `glpi_entities` WRITE;
/*!40000 ALTER TABLE `glpi_entities` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_entities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_entities_data`
--

DROP TABLE IF EXISTS `glpi_entities_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_entities_data` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `ldap_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_entities` (`FK_entities`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_entities_data`
--

LOCK TABLES `glpi_entities_data` WRITE;
/*!40000 ALTER TABLE `glpi_entities_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_entities_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_event_log`
--

DROP TABLE IF EXISTS `glpi_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_event_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` smallint(6) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `comp` (`item`),
  KEY `date` (`date`),
  KEY `itemtype` (`itemtype`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_event_log`
--

LOCK TABLES `glpi_event_log` WRITE;
/*!40000 ALTER TABLE `glpi_event_log` DISABLE KEYS */;
INSERT INTO `glpi_event_log` VALUES (4,-1,'system','2009-03-04 18:25:58','login',3,'glpi connexion de l\'IP : 127.0.0.1'),(5,-1,'system','2009-10-04 21:30:45','login',3,'glpi connexion de l\'IP : 127.0.0.1'),(6,-1,'system','2010-09-28 11:38:33','login',3,'glpi IP connection : 118.100.188.251'),(7,6,'users','2010-09-28 11:39:06','setup',4,'glpi item added admin.');
/*!40000 ALTER TABLE `glpi_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_followups`
--

DROP TABLE IF EXISTS `glpi_followups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_followups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `tracking` int(11) DEFAULT NULL COMMENT 'RELATION to glpi_tracking (ID)',
  `date` datetime DEFAULT NULL,
  `author` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `contents` text COLLATE utf8_unicode_ci,
  `private` int(1) NOT NULL DEFAULT '0',
  `realtime` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `tracking` (`tracking`),
  KEY `author` (`author`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_followups`
--

LOCK TABLES `glpi_followups` WRITE;
/*!40000 ALTER TABLE `glpi_followups` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_followups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_groups`
--

DROP TABLE IF EXISTS `glpi_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `ldap_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_group_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`),
  KEY `ldap_field` (`ldap_field`),
  KEY `FK_entities` (`FK_entities`),
  KEY `ldap_group_dn` (`ldap_group_dn`),
  KEY `ldap_value` (`ldap_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_groups`
--

LOCK TABLES `glpi_groups` WRITE;
/*!40000 ALTER TABLE `glpi_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_history`
--

DROP TABLE IF EXISTS `glpi_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_history` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_glpi_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `device_internal_type` int(11) DEFAULT '0',
  `linked_action` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT '0' COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_glpi_device` (`FK_glpi_device`),
  KEY `device_type` (`device_type`),
  KEY `device_internal_type` (`device_internal_type`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_history`
--

LOCK TABLES `glpi_history` WRITE;
/*!40000 ALTER TABLE `glpi_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_infocoms`
--

DROP TABLE IF EXISTS `glpi_infocoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_infocoms` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` smallint(6) NOT NULL DEFAULT '0',
  `warranty_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FK_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_enterprises (ID)',
  `num_commande` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bon_livraison` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num_immo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `warranty_value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `amort_time` smallint(6) NOT NULL DEFAULT '0',
  `amort_type` smallint(6) NOT NULL DEFAULT '0',
  `amort_coeff` float NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `facture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budget` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_budget (ID)',
  `alert` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_device` (`FK_device`,`device_type`),
  KEY `FK_enterprise` (`FK_enterprise`),
  KEY `buy_date` (`buy_date`),
  KEY `budget` (`budget`),
  KEY `alert` (`alert`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_infocoms`
--

LOCK TABLES `glpi_infocoms` WRITE;
/*!40000 ALTER TABLE `glpi_infocoms` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_infocoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_inst_software`
--

DROP TABLE IF EXISTS `glpi_inst_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_inst_software` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `cID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  `vID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_softwareversions (ID)',
  PRIMARY KEY (`ID`),
  KEY `cID` (`cID`),
  KEY `sID` (`vID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_inst_software`
--

LOCK TABLES `glpi_inst_software` WRITE;
/*!40000 ALTER TABLE `glpi_inst_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_inst_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_kbitems`
--

DROP TABLE IF EXISTS `glpi_kbitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_kbitems` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '1',
  `categoryID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_kbcategories (ID)',
  `question` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `faq` smallint(6) NOT NULL DEFAULT '0',
  `author` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `view` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `categoryID` (`categoryID`),
  KEY `author` (`author`),
  KEY `faq` (`faq`),
  KEY `FK_entities` (`FK_entities`),
  FULLTEXT KEY `fulltext` (`question`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_kbitems`
--

LOCK TABLES `glpi_kbitems` WRITE;
/*!40000 ALTER TABLE `glpi_kbitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_kbitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_links`
--

DROP TABLE IF EXISTS `glpi_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_links` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` int(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_links`
--

LOCK TABLES `glpi_links` WRITE;
/*!40000 ALTER TABLE `glpi_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_links_device`
--

DROP TABLE IF EXISTS `glpi_links_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_links_device` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_links` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_links (ID)',
  `device_type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `link` (`device_type`,`FK_links`),
  KEY `FK_links` (`FK_links`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_links_device`
--

LOCK TABLES `glpi_links_device` WRITE;
/*!40000 ALTER TABLE `glpi_links_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_links_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_mailgate`
--

DROP TABLE IF EXISTS `glpi_mailgate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_mailgate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_mailgate`
--

LOCK TABLES `glpi_mailgate` WRITE;
/*!40000 ALTER TABLE `glpi_mailgate` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_mailgate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_mailing`
--

DROP TABLE IF EXISTS `glpi_mailing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_mailing` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'VALUE in (new, followup, finish, update, resa, alertconsumable, alertcartdridge, alertinfocom, alertlicense)',
  `FK_item` int(11) NOT NULL DEFAULT '0' COMMENT 'if item_type=USER_MAILING_TYPE see define.php *_MAILING constant, else RELATION to various table',
  `item_type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php *_MAILING_TYPE constant',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `mailings` (`type`,`FK_item`,`item_type`),
  KEY `FK_item` (`FK_item`),
  KEY `items` (`item_type`,`FK_item`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_mailing`
--

LOCK TABLES `glpi_mailing` WRITE;
/*!40000 ALTER TABLE `glpi_mailing` DISABLE KEYS */;
INSERT INTO `glpi_mailing` VALUES (1,'resa',3,1),(2,'resa',1,1),(3,'new',3,2),(4,'new',1,1),(5,'update',1,1),(6,'followup',1,1),(7,'finish',1,1),(8,'update',2,1),(9,'update',4,1),(10,'new',3,1),(11,'update',3,1),(12,'followup',3,1),(13,'finish',3,1);
/*!40000 ALTER TABLE `glpi_mailing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_monitors`
--

DROP TABLE IF EXISTS `glpi_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_monitors` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(3) NOT NULL DEFAULT '0',
  `flags_micro` smallint(6) NOT NULL DEFAULT '0',
  `flags_speaker` smallint(6) NOT NULL DEFAULT '0',
  `flags_subd` smallint(6) NOT NULL DEFAULT '0',
  `flags_bnc` smallint(6) NOT NULL DEFAULT '0',
  `flags_dvi` smallint(6) NOT NULL DEFAULT '0',
  `flags_pivot` smallint(6) NOT NULL DEFAULT '0',
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_type_docs (ID)',
  `model` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model_monitors (ID)',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `is_global` smallint(6) NOT NULL DEFAULT '0',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `location` (`location`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `model` (`model`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_monitors`
--

LOCK TABLES `glpi_monitors` WRITE;
/*!40000 ALTER TABLE `glpi_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_monitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_networking`
--

DROP TABLE IF EXISTS `glpi_networking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_networking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `date_mod` datetime DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `domain` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_domain (ID)',
  `network` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_network (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_type_networking (ID)',
  `model` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model_networking (ID)',
  `firmware` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_firmware (ID)',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ifmac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ifaddr` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `location` (`location`),
  KEY `firmware` (`firmware`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `model` (`model`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `network` (`network`),
  KEY `domain` (`domain`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_networking`
--

LOCK TABLES `glpi_networking` WRITE;
/*!40000 ALTER TABLE `glpi_networking` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_networking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_networking_ports`
--

DROP TABLE IF EXISTS `glpi_networking_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_networking_ports` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `on_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `logical_number` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ifaddr` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ifmac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iface` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_iface (ID)',
  `netpoint` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_netpoint (ID)',
  `netmask` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subnet` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `on_device` (`on_device`,`device_type`),
  KEY `netpoint` (`netpoint`),
  KEY `device_type` (`device_type`),
  KEY `iface` (`iface`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_networking_ports`
--

LOCK TABLES `glpi_networking_ports` WRITE;
/*!40000 ALTER TABLE `glpi_networking_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_networking_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_networking_vlan`
--

DROP TABLE IF EXISTS `glpi_networking_vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_networking_vlan` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_port` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_networking_ports (ID)',
  `FK_vlan` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_vlan (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `portvlan` (`FK_port`,`FK_vlan`),
  KEY `FK_vlan` (`FK_vlan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_networking_vlan`
--

LOCK TABLES `glpi_networking_vlan` WRITE;
/*!40000 ALTER TABLE `glpi_networking_vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_networking_vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_networking_wire`
--

DROP TABLE IF EXISTS `glpi_networking_wire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_networking_wire` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `end1` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_networking_ports (ID)',
  `end2` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_networking_ports (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `netwire` (`end1`,`end2`),
  KEY `end2` (`end2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_networking_wire`
--

LOCK TABLES `glpi_networking_wire` WRITE;
/*!40000 ALTER TABLE `glpi_networking_wire` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_networking_wire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_ocs_admin_link`
--

DROP TABLE IF EXISTS `glpi_ocs_admin_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_ocs_admin_link` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `glpi_column` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_column` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_server_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_ocs_admin_link`
--

LOCK TABLES `glpi_ocs_admin_link` WRITE;
/*!40000 ALTER TABLE `glpi_ocs_admin_link` DISABLE KEYS */;
INSERT INTO `glpi_ocs_admin_link` VALUES (1,'otherserial','HARDWARE_ID',1);
/*!40000 ALTER TABLE `glpi_ocs_admin_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_ocs_config`
--

DROP TABLE IF EXISTS `glpi_ocs_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_ocs_config` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `checksum` int(11) NOT NULL DEFAULT '0',
  `import_periph` int(2) NOT NULL DEFAULT '0',
  `import_monitor` int(2) NOT NULL DEFAULT '0',
  `import_software` int(2) NOT NULL DEFAULT '0',
  `import_printer` int(2) NOT NULL DEFAULT '0',
  `import_general_name` int(2) NOT NULL DEFAULT '0',
  `import_general_os` int(2) NOT NULL DEFAULT '0',
  `import_general_serial` int(2) NOT NULL DEFAULT '0',
  `import_general_model` int(2) NOT NULL DEFAULT '0',
  `import_general_enterprise` int(2) NOT NULL DEFAULT '0',
  `import_general_type` int(2) NOT NULL DEFAULT '0',
  `import_general_domain` int(2) NOT NULL DEFAULT '0',
  `import_general_contact` int(2) NOT NULL DEFAULT '0',
  `import_general_comments` int(2) NOT NULL DEFAULT '0',
  `import_device_processor` int(2) NOT NULL DEFAULT '0',
  `import_device_memory` int(2) NOT NULL DEFAULT '0',
  `import_device_hdd` int(2) NOT NULL DEFAULT '0',
  `import_device_iface` int(2) NOT NULL DEFAULT '0',
  `import_device_gfxcard` int(2) NOT NULL DEFAULT '0',
  `import_device_sound` int(2) NOT NULL DEFAULT '0',
  `import_device_drives` int(2) NOT NULL DEFAULT '0',
  `import_device_ports` int(2) NOT NULL DEFAULT '0',
  `import_device_modems` int(2) NOT NULL DEFAULT '0',
  `import_registry` int(11) NOT NULL DEFAULT '0',
  `import_os_serial` int(2) DEFAULT NULL,
  `import_ip` int(2) NOT NULL DEFAULT '0',
  `import_disk` int(2) NOT NULL DEFAULT '0',
  `import_monitor_comments` int(2) NOT NULL DEFAULT '0',
  `import_software_comments` int(11) NOT NULL DEFAULT '0',
  `default_state` int(11) NOT NULL DEFAULT '0',
  `tag_limit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_exclude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_soft_dict` char(1) COLLATE utf8_unicode_ci DEFAULT '0',
  `cron_sync_number` int(11) DEFAULT '1',
  `deconnection_behavior` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `glpi_link_enabled` int(1) NOT NULL DEFAULT '0',
  `link_ip` int(1) NOT NULL DEFAULT '0',
  `link_name` int(1) NOT NULL DEFAULT '0',
  `link_mac_address` int(1) NOT NULL DEFAULT '0',
  `link_serial` int(1) NOT NULL DEFAULT '0',
  `link_if_status` int(11) NOT NULL DEFAULT '0',
  `ocs_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_ocs_config`
--

LOCK TABLES `glpi_ocs_config` WRITE;
/*!40000 ALTER TABLE `glpi_ocs_config` DISABLE KEYS */;
INSERT INTO `glpi_ocs_config` VALUES (1,'localhost','ocs','oscc123','localhost','ocsweb',131015,2,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,0,'',NULL,'0',10,NULL,1,0,0,0,1,0,'');
/*!40000 ALTER TABLE `glpi_ocs_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_ocs_link`
--

DROP TABLE IF EXISTS `glpi_ocs_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_ocs_link` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `glpi_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  `ocs_id` int(11) NOT NULL DEFAULT '0',
  `ocs_deviceid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auto_update` int(2) NOT NULL DEFAULT '1',
  `last_update` datetime DEFAULT NULL,
  `last_ocs_update` datetime DEFAULT NULL,
  `computer_update` longtext COLLATE utf8_unicode_ci,
  `import_device` longtext COLLATE utf8_unicode_ci,
  `import_disk` longtext COLLATE utf8_unicode_ci,
  `import_software` longtext COLLATE utf8_unicode_ci,
  `import_monitor` longtext COLLATE utf8_unicode_ci,
  `import_peripheral` longtext COLLATE utf8_unicode_ci,
  `import_printers` longtext COLLATE utf8_unicode_ci,
  `ocs_server_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_ocs_config (ID)',
  `import_ip` longtext COLLATE utf8_unicode_ci,
  `ocs_agent_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ocs_server_id` (`ocs_server_id`,`ocs_id`),
  KEY `glpi_id` (`glpi_id`),
  KEY `auto_update` (`auto_update`),
  KEY `last_update` (`last_update`),
  KEY `ocs_deviceid` (`ocs_deviceid`),
  KEY `last_ocs_update` (`ocs_server_id`,`last_ocs_update`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_ocs_link`
--

LOCK TABLES `glpi_ocs_link` WRITE;
/*!40000 ALTER TABLE `glpi_ocs_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_ocs_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_peripherals`
--

DROP TABLE IF EXISTS `glpi_peripherals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_peripherals` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_type_peripherals (ID)',
  `model` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model_peripherals (ID)',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `is_global` smallint(6) NOT NULL DEFAULT '0',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `location` (`location`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `model` (`model`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_peripherals`
--

LOCK TABLES `glpi_peripherals` WRITE;
/*!40000 ALTER TABLE `glpi_peripherals` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_peripherals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_phones`
--

DROP TABLE IF EXISTS `glpi_phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_phones` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firmware` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_type_phones (ID)',
  `model` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model_phones (ID)',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_phone_power (ID)',
  `number_line` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flags_casque` smallint(6) NOT NULL DEFAULT '0',
  `flags_hp` smallint(6) NOT NULL DEFAULT '0',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `is_global` smallint(6) NOT NULL DEFAULT '0',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `name` (`name`),
  KEY `location` (`location`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `type` (`type`),
  KEY `model` (`model`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `power` (`power`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_phones`
--

LOCK TABLES `glpi_phones` WRITE;
/*!40000 ALTER TABLE `glpi_phones` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_phones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_plugins`
--

DROP TABLE IF EXISTS `glpi_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_plugins` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'see define.php PLUGIN_* constant',
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `homepage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`directory`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_plugins`
--

LOCK TABLES `glpi_plugins` WRITE;
/*!40000 ALTER TABLE `glpi_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_printers`
--

DROP TABLE IF EXISTS `glpi_printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_printers` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flags_serial` smallint(6) NOT NULL DEFAULT '0',
  `flags_par` smallint(6) NOT NULL DEFAULT '0',
  `flags_usb` smallint(6) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `ramSize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `domain` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_domain (ID)',
  `network` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_network (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_type_printers (ID)',
  `model` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_model_printers (ID)',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `is_global` smallint(6) NOT NULL DEFAULT '0',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `initial_pages` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `location` (`location`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `model` (`model`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `network` (`network`),
  KEY `domain` (`domain`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_printers`
--

LOCK TABLES `glpi_printers` WRITE;
/*!40000 ALTER TABLE `glpi_printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_profiles`
--

DROP TABLE IF EXISTS `glpi_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_profiles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'helpdesk',
  `is_default` smallint(6) NOT NULL DEFAULT '0',
  `computer` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monitor` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `software` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `networking` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `printer` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `peripheral` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cartridge` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `consumable` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_enterprise` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contract` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `infocom` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `knowbase` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `faq` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reservation_helpdesk` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reservation_central` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reports` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocsng` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `view_ocsng` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sync_ocsng` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dropdown` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_dropdown` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `typedoc` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_tracking` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_ocs` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_ldap` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_softwarecategories` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `search_config` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `search_config_global` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `check_update` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_auth_method` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transfer` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logs` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reminder_public` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bookmark_public` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `backup` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delete_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_all_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `update_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `own_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `steal_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assign_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_all_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_assign_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_full_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observe_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `update_followups` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_planning` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_group_planning` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_all_planning` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `statistic` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_update` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `helpdesk_hardware` smallint(6) NOT NULL DEFAULT '0',
  `helpdesk_hardware_type` int(11) NOT NULL DEFAULT '0',
  `show_group_ticket` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_group_hardware` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_dictionnary_software` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_dictionnary_dropdown` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_profiles`
--

LOCK TABLES `glpi_profiles` WRITE;
/*!40000 ALTER TABLE `glpi_profiles` DISABLE KEYS */;
INSERT INTO `glpi_profiles` VALUES (1,'post-only','helpdesk',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'r','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'1',1,8388674,'0','0',NULL,NULL),(2,'normal','central',0,'r','r','r','r','r','r','r','r','r','r','r','r','r','r','r','r','1','r','r',NULL,'r',NULL,NULL,NULL,NULL,'r','r',NULL,NULL,NULL,NULL,NULL,'w',NULL,'r',NULL,'r','r','r',NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1','0','0','1','0','0','1','1','0','1','0','1','0','0','1','1',1,8388674,'0','0',NULL,NULL),(3,'admin','central',0,'w','w','w','w','w','w','w','w','w','w','w','w','w','w','w','w','1','w','r','w','r','w','w','w','w','w','w',NULL,NULL,NULL,NULL,NULL,'w','w','r','r','w','w','w',NULL,NULL,NULL,NULL,NULL,NULL,'1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',3,8388674,'0','0',NULL,NULL),(4,'super-admin','central',0,'w','w','w','w','w','w','w','w','w','w','w','w','w','w','w','w','1','w','r','w','r','w','w','w','w','w','w','w','w','w','w','w','w','w','r','w','w','w','w','w','w','r','w','w','w','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',3,8388674,'0','0','w','w');
/*!40000 ALTER TABLE `glpi_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_registry`
--

DROP TABLE IF EXISTS `glpi_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_registry` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `computer_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  `registry_hive` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registry_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registry_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registry_ocs_name` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `computer_id` (`computer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_registry`
--

LOCK TABLES `glpi_registry` WRITE;
/*!40000 ALTER TABLE `glpi_registry` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_reminder`
--

DROP TABLE IF EXISTS `glpi_reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_reminder` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `date` datetime DEFAULT NULL,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `private` tinyint(1) NOT NULL DEFAULT '1',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `rv` smallint(6) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `state` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `date` (`date`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `FK_entities` (`FK_entities`),
  KEY `rv` (`rv`),
  KEY `FK_users` (`FK_users`),
  KEY `recursive` (`recursive`),
  KEY `private` (`private`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_reminder`
--

LOCK TABLES `glpi_reminder` WRITE;
/*!40000 ALTER TABLE `glpi_reminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_reminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_reservation_item`
--

DROP TABLE IF EXISTS `glpi_reservation_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_reservation_item` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `device_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `id_device` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  `active` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `reservationitem` (`device_type`,`id_device`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_reservation_item`
--

LOCK TABLES `glpi_reservation_item` WRITE;
/*!40000 ALTER TABLE `glpi_reservation_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_reservation_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_reservation_resa`
--

DROP TABLE IF EXISTS `glpi_reservation_resa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_reservation_resa` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_item` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_reservation_item (ID)',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `id_user` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `id_item` (`id_item`),
  KEY `id_user` (`id_user`),
  KEY `begin` (`begin`),
  KEY `end` (`end`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_reservation_resa`
--

LOCK TABLES `glpi_reservation_resa` WRITE;
/*!40000 ALTER TABLE `glpi_reservation_resa` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_reservation_resa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_manufacturer`
--

DROP TABLE IF EXISTS `glpi_rule_cache_manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_manufacturer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_manufacturer`
--

LOCK TABLES `glpi_rule_cache_manufacturer` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_manufacturer` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_manufacturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_model_computer`
--

DROP TABLE IF EXISTS `glpi_rule_cache_model_computer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_model_computer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_model_computer`
--

LOCK TABLES `glpi_rule_cache_model_computer` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_model_computer` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_model_computer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_model_monitor`
--

DROP TABLE IF EXISTS `glpi_rule_cache_model_monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_model_monitor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_model_monitor`
--

LOCK TABLES `glpi_rule_cache_model_monitor` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_model_monitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_model_monitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_model_networking`
--

DROP TABLE IF EXISTS `glpi_rule_cache_model_networking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_model_networking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_model_networking`
--

LOCK TABLES `glpi_rule_cache_model_networking` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_model_networking` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_model_networking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_model_peripheral`
--

DROP TABLE IF EXISTS `glpi_rule_cache_model_peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_model_peripheral` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_model_peripheral`
--

LOCK TABLES `glpi_rule_cache_model_peripheral` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_model_peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_model_peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_model_phone`
--

DROP TABLE IF EXISTS `glpi_rule_cache_model_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_model_phone` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_model_phone`
--

LOCK TABLES `glpi_rule_cache_model_phone` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_model_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_model_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_model_printer`
--

DROP TABLE IF EXISTS `glpi_rule_cache_model_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_model_printer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_model_printer`
--

LOCK TABLES `glpi_rule_cache_model_printer` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_model_printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_model_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_os`
--

DROP TABLE IF EXISTS `glpi_rule_cache_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_os` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_os`
--

LOCK TABLES `glpi_rule_cache_os` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_os_sp`
--

DROP TABLE IF EXISTS `glpi_rule_cache_os_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_os_sp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_os_sp`
--

LOCK TABLES `glpi_rule_cache_os_sp` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_os_sp` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_os_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_os_version`
--

DROP TABLE IF EXISTS `glpi_rule_cache_os_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_os_version` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_os_version`
--

LOCK TABLES `glpi_rule_cache_os_version` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_os_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_os_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_software`
--

DROP TABLE IF EXISTS `glpi_rule_cache_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_software` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_manufacturer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ignore_ocs_import` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_software`
--

LOCK TABLES `glpi_rule_cache_software` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_type_computer`
--

DROP TABLE IF EXISTS `glpi_rule_cache_type_computer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_type_computer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_type_computer`
--

LOCK TABLES `glpi_rule_cache_type_computer` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_type_computer` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_type_computer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_type_monitor`
--

DROP TABLE IF EXISTS `glpi_rule_cache_type_monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_type_monitor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_type_monitor`
--

LOCK TABLES `glpi_rule_cache_type_monitor` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_type_monitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_type_monitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_type_networking`
--

DROP TABLE IF EXISTS `glpi_rule_cache_type_networking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_type_networking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_type_networking`
--

LOCK TABLES `glpi_rule_cache_type_networking` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_type_networking` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_type_networking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_type_peripheral`
--

DROP TABLE IF EXISTS `glpi_rule_cache_type_peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_type_peripheral` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_type_peripheral`
--

LOCK TABLES `glpi_rule_cache_type_peripheral` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_type_peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_type_peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_type_phone`
--

DROP TABLE IF EXISTS `glpi_rule_cache_type_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_type_phone` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_type_phone`
--

LOCK TABLES `glpi_rule_cache_type_phone` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_type_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_type_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rule_cache_type_printer`
--

DROP TABLE IF EXISTS `glpi_rule_cache_type_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rule_cache_type_printer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rule_id` (`rule_id`),
  KEY `old_value` (`old_value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rule_cache_type_printer`
--

LOCK TABLES `glpi_rule_cache_type_printer` WRITE;
/*!40000 ALTER TABLE `glpi_rule_cache_type_printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_rule_cache_type_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rules_actions`
--

DROP TABLE IF EXISTS `glpi_rules_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rules_actions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_rules` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'VALUE IN (assign, regex_result, append_regex_result, affectbyip, affectbyfqdn, affectbymac)',
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_rules` (`FK_rules`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rules_actions`
--

LOCK TABLES `glpi_rules_actions` WRITE;
/*!40000 ALTER TABLE `glpi_rules_actions` DISABLE KEYS */;
INSERT INTO `glpi_rules_actions` VALUES (1,1,'assign','FK_entities','0'),(2,2,'assign','FK_entities','0');
/*!40000 ALTER TABLE `glpi_rules_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rules_criterias`
--

DROP TABLE IF EXISTS `glpi_rules_criterias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rules_criterias` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_rules` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_rules_descriptions (ID)',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` smallint(4) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_rules` (`FK_rules`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rules_criterias`
--

LOCK TABLES `glpi_rules_criterias` WRITE;
/*!40000 ALTER TABLE `glpi_rules_criterias` DISABLE KEYS */;
INSERT INTO `glpi_rules_criterias` VALUES (1,1,'TAG',0,'*'),(2,2,'uid',0,'*'),(3,2,'samaccountname',0,'*'),(4,2,'MAIL_EMAIL',0,'*');
/*!40000 ALTER TABLE `glpi_rules_criterias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rules_descriptions`
--

DROP TABLE IF EXISTS `glpi_rules_descriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rules_descriptions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `sub_type` smallint(4) NOT NULL DEFAULT '0' COMMENT 'see define.php RULE_* constant',
  `ranking` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `match` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `active` int(1) NOT NULL DEFAULT '1',
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rules_descriptions`
--

LOCK TABLES `glpi_rules_descriptions` WRITE;
/*!40000 ALTER TABLE `glpi_rules_descriptions` DISABLE KEYS */;
INSERT INTO `glpi_rules_descriptions` VALUES (1,-1,0,0,'Root','','AND',1,NULL),(2,-1,1,1,'Root','','OR',1,NULL);
/*!40000 ALTER TABLE `glpi_rules_descriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_rules_ldap_parameters`
--

DROP TABLE IF EXISTS `glpi_rules_ldap_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_rules_ldap_parameters` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_type` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_rules_ldap_parameters`
--

LOCK TABLES `glpi_rules_ldap_parameters` WRITE;
/*!40000 ALTER TABLE `glpi_rules_ldap_parameters` DISABLE KEYS */;
INSERT INTO `glpi_rules_ldap_parameters` VALUES (1,'(LDAP)Organization','o',1),(2,'(LDAP)Common Name','cn',1),(3,'(LDAP)Department Number','departmentnumber',1),(4,'(LDAP)Email','mail',1),(5,'Object Class','objectclass',1),(6,'(LDAP)User ID','uid',1),(7,'(LDAP)Telephone Number','phone',1),(8,'(LDAP)Employee Number','employeenumber',1),(9,'(LDAP)Manager','manager',1),(10,'(LDAP)DistinguishedName','dn',1),(12,'(AD)User ID','samaccountname',1),(13,'(LDAP) Title','title',1);
/*!40000 ALTER TABLE `glpi_rules_ldap_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_software`
--

DROP TABLE IF EXISTS `glpi_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_software` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `location` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `tech_num` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `platform` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_os (ID)',
  `is_update` smallint(6) NOT NULL DEFAULT '0',
  `update_software` int(11) NOT NULL DEFAULT '-1' COMMENT 'RELATION to glpi_software (ID)',
  `FK_glpi_enterprise` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_manufacturer (ID)',
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `is_template` smallint(6) NOT NULL DEFAULT '0',
  `tplname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `oldstate` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `helpdesk_visible` int(11) NOT NULL DEFAULT '1',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_software_category (ID)',
  PRIMARY KEY (`ID`),
  KEY `platform` (`platform`),
  KEY `location` (`location`),
  KEY `FK_glpi_enterprise` (`FK_glpi_enterprise`),
  KEY `date_mod` (`date_mod`),
  KEY `tech_num` (`tech_num`),
  KEY `name` (`name`),
  KEY `FK_groups` (`FK_groups`),
  KEY `FK_users` (`FK_users`),
  KEY `update_software` (`update_software`),
  KEY `FK_entities` (`FK_entities`),
  KEY `is_template` (`is_template`),
  KEY `is_update` (`is_update`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_software`
--

LOCK TABLES `glpi_software` WRITE;
/*!40000 ALTER TABLE `glpi_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_softwarelicenses`
--

DROP TABLE IF EXISTS `glpi_softwarelicenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_softwarelicenses` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `sID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_software (ID)',
  `FK_entities` int(11) NOT NULL DEFAULT '0',
  `recursive` tinyint(1) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_licensetypes (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `buy_version` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_softwareversions (ID)',
  `use_version` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_softwareversions (ID)',
  `expire` date DEFAULT NULL,
  `FK_computers` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_computers (ID)',
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `sID` (`sID`),
  KEY `FK_entities` (`FK_entities`),
  KEY `buy_version` (`buy_version`),
  KEY `use_version` (`use_version`),
  KEY `FK_computers` (`FK_computers`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_softwarelicenses`
--

LOCK TABLES `glpi_softwarelicenses` WRITE;
/*!40000 ALTER TABLE `glpi_softwarelicenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_softwarelicenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_softwareversions`
--

DROP TABLE IF EXISTS `glpi_softwareversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_softwareversions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `sID` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_software (ID)',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_state (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `sID` (`sID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_softwareversions`
--

LOCK TABLES `glpi_softwareversions` WRITE;
/*!40000 ALTER TABLE `glpi_softwareversions` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_softwareversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_tracking`
--

DROP TABLE IF EXISTS `glpi_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_tracking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'new',
  `author` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `recipient` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_group` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `request_type` smallint(6) NOT NULL DEFAULT '0',
  `assign` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `assign_ent` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_enterprises (ID)',
  `assign_group` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  `device_type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php *_TYPE constant',
  `computer` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to device_type (ID)',
  `contents` longtext COLLATE utf8_unicode_ci,
  `priority` smallint(6) NOT NULL DEFAULT '1',
  `uemail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emailupdates` smallint(6) NOT NULL DEFAULT '0',
  `realtime` float NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_tracking_category (ID)',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  KEY `computer` (`computer`),
  KEY `author` (`author`),
  KEY `assign` (`assign`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `category` (`category`),
  KEY `FK_group` (`FK_group`),
  KEY `assign_ent` (`assign_ent`),
  KEY `device_type` (`device_type`),
  KEY `priority` (`priority`),
  KEY `request_type` (`request_type`),
  KEY `FK_entities` (`FK_entities`),
  KEY `recipient` (`recipient`),
  KEY `assign_group` (`assign_group`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_tracking`
--

LOCK TABLES `glpi_tracking` WRITE;
/*!40000 ALTER TABLE `glpi_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_tracking_planning`
--

DROP TABLE IF EXISTS `glpi_tracking_planning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_tracking_planning` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_followup` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_followups (ID)',
  `id_assign` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `state` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `id_assign` (`id_assign`),
  KEY `id_followup` (`id_followup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_tracking_planning`
--

LOCK TABLES `glpi_tracking_planning` WRITE;
/*!40000 ALTER TABLE `glpi_tracking_planning` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_tracking_planning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_transfers`
--

DROP TABLE IF EXISTS `glpi_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_transfers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keep_tickets` smallint(6) NOT NULL DEFAULT '0',
  `keep_networklinks` smallint(6) NOT NULL DEFAULT '0',
  `keep_reservations` smallint(6) NOT NULL DEFAULT '0',
  `keep_history` smallint(6) NOT NULL DEFAULT '0',
  `keep_devices` smallint(6) NOT NULL DEFAULT '0',
  `keep_infocoms` smallint(6) NOT NULL DEFAULT '0',
  `keep_dc_monitor` smallint(6) NOT NULL DEFAULT '0',
  `clean_dc_monitor` smallint(6) NOT NULL DEFAULT '0',
  `keep_dc_phone` smallint(6) NOT NULL DEFAULT '0',
  `clean_dc_phone` smallint(6) NOT NULL DEFAULT '0',
  `keep_dc_peripheral` smallint(6) NOT NULL DEFAULT '0',
  `clean_dc_peripheral` smallint(6) NOT NULL DEFAULT '0',
  `keep_dc_printer` smallint(6) NOT NULL DEFAULT '0',
  `clean_dc_printer` smallint(6) NOT NULL DEFAULT '0',
  `keep_enterprises` smallint(6) NOT NULL DEFAULT '0',
  `clean_enterprises` smallint(6) NOT NULL DEFAULT '0',
  `keep_contacts` smallint(6) NOT NULL DEFAULT '0',
  `clean_contacts` smallint(6) NOT NULL DEFAULT '0',
  `keep_contracts` smallint(6) NOT NULL DEFAULT '0',
  `clean_contracts` smallint(6) NOT NULL DEFAULT '0',
  `keep_softwares` smallint(6) NOT NULL DEFAULT '0',
  `clean_softwares` smallint(6) NOT NULL DEFAULT '0',
  `keep_documents` smallint(6) NOT NULL DEFAULT '0',
  `clean_documents` smallint(6) NOT NULL DEFAULT '0',
  `keep_cartridges_type` smallint(6) NOT NULL DEFAULT '0',
  `clean_cartridges_type` smallint(6) NOT NULL DEFAULT '0',
  `keep_cartridges` smallint(6) NOT NULL DEFAULT '0',
  `keep_consumables` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_transfers`
--

LOCK TABLES `glpi_transfers` WRITE;
/*!40000 ALTER TABLE `glpi_transfers` DISABLE KEYS */;
INSERT INTO `glpi_transfers` VALUES (1,'complete',2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `glpi_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_computers`
--

DROP TABLE IF EXISTS `glpi_type_computers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_computers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_computers`
--

LOCK TABLES `glpi_type_computers` WRITE;
/*!40000 ALTER TABLE `glpi_type_computers` DISABLE KEYS */;
INSERT INTO `glpi_type_computers` VALUES (1,'Serveur',NULL);
/*!40000 ALTER TABLE `glpi_type_computers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_docs`
--

DROP TABLE IF EXISTS `glpi_type_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_docs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `upload` smallint(6) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `extension` (`ext`),
  KEY `name` (`name`),
  KEY `upload` (`upload`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_docs`
--

LOCK TABLES `glpi_type_docs` WRITE;
/*!40000 ALTER TABLE `glpi_type_docs` DISABLE KEYS */;
INSERT INTO `glpi_type_docs` VALUES (1,'JPEG','jpg','jpg-dist.png','',1,'2004-12-13 19:47:21'),(2,'PNG','png','png-dist.png','',1,'2004-12-13 19:47:21'),(3,'GIF','gif','gif-dist.png','',1,'2004-12-13 19:47:21'),(4,'BMP','bmp','bmp-dist.png','',1,'2004-12-13 19:47:21'),(5,'Photoshop','psd','psd-dist.png','',1,'2004-12-13 19:47:21'),(6,'TIFF','tif','tif-dist.png','',1,'2004-12-13 19:47:21'),(7,'AIFF','aiff','aiff-dist.png','',1,'2004-12-13 19:47:21'),(8,'Windows Media','asf','asf-dist.png','',1,'2004-12-13 19:47:21'),(9,'Windows Media','avi','avi-dist.png','',1,'2004-12-13 19:47:21'),(44,'C source','c','','',1,'2004-12-13 19:47:22'),(27,'RealAudio','rm','rm-dist.png','',1,'2004-12-13 19:47:21'),(16,'Midi','mid','mid-dist.png','',1,'2004-12-13 19:47:21'),(17,'QuickTime','mov','mov-dist.png','',1,'2004-12-13 19:47:21'),(18,'MP3','mp3','mp3-dist.png','',1,'2004-12-13 19:47:21'),(19,'MPEG','mpg','mpg-dist.png','',1,'2004-12-13 19:47:21'),(20,'Ogg Vorbis','ogg','ogg-dist.png','',1,'2004-12-13 19:47:21'),(24,'QuickTime','qt','qt-dist.png','',1,'2004-12-13 19:47:21'),(10,'BZip','bz2','bz2-dist.png','',1,'2004-12-13 19:47:21'),(25,'RealAudio','ra','ra-dist.png','',1,'2004-12-13 19:47:21'),(26,'RealAudio','ram','ram-dist.png','',1,'2004-12-13 19:47:21'),(11,'Word','doc','doc-dist.png','',1,'2004-12-13 19:47:21'),(12,'DjVu','djvu','','',1,'2004-12-13 19:47:21'),(42,'MNG','mng','','',1,'2004-12-13 19:47:22'),(13,'PostScript','eps','ps-dist.png','',1,'2004-12-13 19:47:21'),(14,'GZ','gz','gz-dist.png','',1,'2004-12-13 19:47:21'),(37,'WAV','wav','wav-dist.png','',1,'2004-12-13 19:47:22'),(15,'HTML','html','html-dist.png','',1,'2004-12-13 19:47:21'),(34,'Flash','swf','','',1,'2004-12-13 19:47:22'),(21,'PDF','pdf','pdf-dist.png','',1,'2004-12-13 19:47:21'),(22,'PowerPoint','ppt','ppt-dist.png','',1,'2004-12-13 19:47:21'),(23,'PostScript','ps','ps-dist.png','',1,'2004-12-13 19:47:21'),(40,'Windows Media','wmv','','',1,'2004-12-13 19:47:22'),(28,'RTF','rtf','rtf-dist.png','',1,'2004-12-13 19:47:21'),(29,'StarOffice','sdd','sdd-dist.png','',1,'2004-12-13 19:47:22'),(30,'StarOffice','sdw','sdw-dist.png','',1,'2004-12-13 19:47:22'),(31,'Stuffit','sit','sit-dist.png','',1,'2004-12-13 19:47:22'),(43,'Adobe Illustrator','ai','ai-dist.png','',1,'2004-12-13 19:47:22'),(32,'OpenOffice Impress','sxi','sxi-dist.png','',1,'2004-12-13 19:47:22'),(33,'OpenOffice','sxw','sxw-dist.png','',1,'2004-12-13 19:47:22'),(46,'DVI','dvi','dvi-dist.png','',1,'2004-12-13 19:47:22'),(35,'TGZ','tgz','tgz-dist.png','',1,'2004-12-13 19:47:22'),(36,'texte','txt','txt-dist.png','',1,'2004-12-13 19:47:22'),(49,'RedHat/Mandrake/SuSE','rpm','rpm-dist.png','',1,'2004-12-13 19:47:22'),(38,'Excel','xls','xls-dist.png','',1,'2004-12-13 19:47:22'),(39,'XML','xml','xml-dist.png','',1,'2004-12-13 19:47:22'),(41,'Zip','zip','zip-dist.png','',1,'2004-12-13 19:47:22'),(45,'Debian','deb','deb-dist.png','',1,'2004-12-13 19:47:22'),(47,'C header','h','','',1,'2004-12-13 19:47:22'),(48,'Pascal','pas','','',1,'2004-12-13 19:47:22'),(50,'OpenOffice Calc','sxc','sxc-dist.png','',1,'2004-12-13 19:47:22'),(51,'LaTeX','tex','tex-dist.png','',1,'2004-12-13 19:47:22'),(52,'GIMP multi-layer','xcf','xcf-dist.png','',1,'2004-12-13 19:47:22'),(53,'JPEG','jpeg','jpg-dist.png','',1,'2005-03-07 22:23:17'),(54,'Oasis Open Office Writer','odt','odt-dist.png','',1,'2006-01-21 17:41:13'),(55,'Oasis Open Office Calc','ods','ods-dist.png','',1,'2006-01-21 17:41:31'),(56,'Oasis Open Office Impress','odp','odp-dist.png','',1,'2006-01-21 17:42:54'),(57,'Oasis Open Office Impress Template','otp','odp-dist.png','',1,'2006-01-21 17:43:58'),(58,'Oasis Open Office Writer Template','ott','odt-dist.png','',1,'2006-01-21 17:44:41'),(59,'Oasis Open Office Calc Template','ots','ods-dist.png','',1,'2006-01-21 17:45:30'),(60,'Oasis Open Office Math','odf','odf-dist.png','',1,'2006-01-21 17:48:05'),(61,'Oasis Open Office Draw','odg','odg-dist.png','',1,'2006-01-21 17:48:31'),(62,'Oasis Open Office Draw Template','otg','odg-dist.png','',1,'2006-01-21 17:49:46'),(63,'Oasis Open Office Base','odb','odb-dist.png','',1,'2006-01-21 18:03:34'),(64,'Oasis Open Office HTML','oth','oth-dist.png','',1,'2006-01-21 18:05:27'),(65,'Oasis Open Office Writer Master','odm','odm-dist.png','',1,'2006-01-21 18:06:34'),(66,'Oasis Open Office Chart','odc','','',1,'2006-01-21 18:07:48'),(67,'Oasis Open Office Image','odi','','',1,'2006-01-21 18:08:18');
/*!40000 ALTER TABLE `glpi_type_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_monitors`
--

DROP TABLE IF EXISTS `glpi_type_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_monitors` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_monitors`
--

LOCK TABLES `glpi_type_monitors` WRITE;
/*!40000 ALTER TABLE `glpi_type_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_type_monitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_networking`
--

DROP TABLE IF EXISTS `glpi_type_networking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_networking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_networking`
--

LOCK TABLES `glpi_type_networking` WRITE;
/*!40000 ALTER TABLE `glpi_type_networking` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_type_networking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_peripherals`
--

DROP TABLE IF EXISTS `glpi_type_peripherals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_peripherals` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_peripherals`
--

LOCK TABLES `glpi_type_peripherals` WRITE;
/*!40000 ALTER TABLE `glpi_type_peripherals` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_type_peripherals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_phones`
--

DROP TABLE IF EXISTS `glpi_type_phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_phones` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_phones`
--

LOCK TABLES `glpi_type_phones` WRITE;
/*!40000 ALTER TABLE `glpi_type_phones` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_type_phones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_type_printers`
--

DROP TABLE IF EXISTS `glpi_type_printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_type_printers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_type_printers`
--

LOCK TABLES `glpi_type_printers` WRITE;
/*!40000 ALTER TABLE `glpi_type_printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_type_printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_users`
--

DROP TABLE IF EXISTS `glpi_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_md5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(11) DEFAULT NULL COMMENT 'RELATION to glpi_dropdown_locations (ID)',
  `tracking_order` smallint(6) DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php CFG_GLPI[language] array',
  `use_mode` smallint(6) NOT NULL DEFAULT '0' COMMENT 'see define.php *_MODE constant',
  `list_limit` int(11) DEFAULT NULL,
  `active` int(2) NOT NULL DEFAULT '1',
  `comments` text COLLATE utf8_unicode_ci,
  `id_auth` int(11) NOT NULL DEFAULT '-1',
  `auth_method` int(11) NOT NULL DEFAULT '-1' COMMENT 'see define.php AUTH_* constant',
  `last_login` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT '0',
  `FK_profiles` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_profiles (ID)',
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `title` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_user_titles (ID)',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_dropdown_user_types (ID)',
  `dateformat` smallint(6) DEFAULT NULL,
  `numberformat` smallint(6) DEFAULT NULL,
  `view_ID` smallint(6) DEFAULT NULL,
  `dropdown_limit` int(11) DEFAULT NULL,
  `flat_dropdowntree` smallint(6) DEFAULT NULL,
  `num_of_events` int(11) DEFAULT NULL,
  `nextprev_item` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jobs_at_login` smallint(6) DEFAULT NULL,
  `priority_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expand_soft_categorized` int(1) DEFAULT NULL,
  `expand_soft_not_categorized` int(1) DEFAULT NULL,
  `followup_private` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`),
  KEY `location` (`location`),
  KEY `firstname` (`firstname`),
  KEY `realname` (`realname`),
  KEY `deleted` (`deleted`),
  KEY `title` (`title`),
  KEY `type` (`type`),
  KEY `active` (`active`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_users`
--

LOCK TABLES `glpi_users` WRITE;
/*!40000 ALTER TABLE `glpi_users` DISABLE KEYS */;
INSERT INTO `glpi_users` VALUES (2,'glpi','','41ece51526515624ff89973668497d00','','','','','',NULL,0,1,NULL,0,20,1,NULL,-1,1,'2010-09-28 11:38:32','2009-10-04 21:30:45',0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'post-only','*5683D7F638D6598D057638B1957F194E4CA974FB','3177926a7314de24680a9938aaa97703','','','','','',NULL,0,0,'en_GB',0,20,1,NULL,-1,-1,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'tech','*B09F1B2C210DEEA69C662977CC69C6C461965B09','d9f9133fb120cd6096870bc2b496805b','','','','','',NULL,0,1,'en_GB',0,20,1,NULL,-1,-1,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'normal','*F3F91B23FC1DB728B49B1F22DEE3D7A839E10F0E','fea087517c26fadd409bd4b9dc642555','','','','','',NULL,0,0,'en_GB',0,20,1,NULL,-1,-1,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'admin','','0192023a7bbd73250516f069df18b500','','','','','','',0,NULL,NULL,0,NULL,1,'',-1,1,NULL,'2010-09-28 11:39:06',0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `glpi_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_users_groups`
--

DROP TABLE IF EXISTS `glpi_users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_users_groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_groups` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (ID)',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `usergroup` (`FK_users`,`FK_groups`),
  KEY `FK_groups` (`FK_groups`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_users_groups`
--

LOCK TABLES `glpi_users_groups` WRITE;
/*!40000 ALTER TABLE `glpi_users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `glpi_users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glpi_users_profiles`
--

DROP TABLE IF EXISTS `glpi_users_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glpi_users_profiles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FK_users` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (ID)',
  `FK_profiles` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_profiles (ID)',
  `FK_entities` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_entities (ID)',
  `recursive` smallint(6) NOT NULL DEFAULT '1',
  `dynamic` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `FK_users` (`FK_users`),
  KEY `FK_profiles` (`FK_profiles`),
  KEY `FK_entities` (`FK_entities`),
  KEY `recursive` (`recursive`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glpi_users_profiles`
--

LOCK TABLES `glpi_users_profiles` WRITE;
/*!40000 ALTER TABLE `glpi_users_profiles` DISABLE KEYS */;
INSERT INTO `glpi_users_profiles` VALUES (2,2,4,0,1,0),(3,3,1,0,1,0),(4,4,4,0,1,0),(5,5,2,0,1,0),(6,6,1,0,0,0),(7,6,4,0,0,0);
/*!40000 ALTER TABLE `glpi_users_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-09-28 11:44:46
