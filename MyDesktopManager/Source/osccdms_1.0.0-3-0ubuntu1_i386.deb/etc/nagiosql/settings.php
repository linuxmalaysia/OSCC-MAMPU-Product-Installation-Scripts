<?php
exit;
?>
;///////////////////////////////////////////////////////////////////////////////
;
; NagiosQL
;
;///////////////////////////////////////////////////////////////////////////////
;
; (c) 2008, 2009 by Martin Willisegger
;
; Project  : NagiosQL
; Component: Database Configuration
; Website  : http://www.nagiosql.org
; Date     : September 28, 2010, 12:36 pm
; Version  : 3.0.3
; Revision : $LastChangedRevision: 715 $
;
;///////////////////////////////////////////////////////////////////////////////
[db]
server       = localhost
port         = 3306
database     = db_nagiosql_v3
username     = nagiosql_user
password     = nagiosql_pass
[common]
install      = passed
