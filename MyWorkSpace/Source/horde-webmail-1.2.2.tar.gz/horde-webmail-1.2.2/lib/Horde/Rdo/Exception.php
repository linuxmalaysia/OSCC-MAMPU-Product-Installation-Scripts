<?php
/**
 * @category Horde
 * @package Horde_Rdo
 */

/**
 * Rdo Exception class.
 *
 * @category Horde
 * @package Horde_Rdo
 */
class Horde_Rdo_Exception extends Exception {}
