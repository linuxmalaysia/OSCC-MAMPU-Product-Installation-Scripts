function enter_key_trap()
{
    return false;
}
