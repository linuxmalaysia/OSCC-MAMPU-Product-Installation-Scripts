$mime_drivers['imp']['pgp']['highlight'] = true;
$mime_drivers['imp']['pkcs7']['highlight'] = true;
