<?php
/**
 * $Horde: imp/config/spelling.php.dist,v 1.1.2.1 2007/12/20 13:59:20 jan Exp $
 *
 * This file defines a custom list of words that will be added to the spell
 * checker dictionary.
 */

/* Default list (English). */
$ignore_list = array(
    'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct',
    'nov', 'dec', 'fwd', 'http', 'https', 'html', 'email', 'bcc', 'jpg', 'gif'
);
